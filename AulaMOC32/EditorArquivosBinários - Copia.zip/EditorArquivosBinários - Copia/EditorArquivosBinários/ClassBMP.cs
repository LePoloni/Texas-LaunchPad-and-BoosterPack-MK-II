﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//Incluido manualmente
using System.Windows.Forms;
using System.IO;

namespace EditorArquivosBinários
{
    public class ClassBMP
    {
        //Atributos
        string nomeArquivo;
        //Método construtor
        public ClassBMP(string nomeArq)
        {
            nomeArquivo = nomeArq;
        }
        //Métodos
        /// <summary>
        /// Lê arquivo de imagem em HEXA e atualiza caixa de texto
        /// </summary>
        /// <param name="tb">caixa de texto que será atualizada passada por referência</param>
        /// <returns>tamanho do arquivo em de bytes</returns>
        public int leHEXA(TextBox tb)
        {
            int l = 0;
            try
            {
                //Lê todos os bytes do arquivo
                byte[] arquivo = File.ReadAllBytes(nomeArquivo);
                l = arquivo.Length;
                StringBuilder sb = new StringBuilder(l);
                for (int i = 0; i < l; i++)
                {
                    sb.AppendFormat("{0:x2}", arquivo[i]);  //Mostra em hexa
                }
                tb.Text = sb.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro ao tentar acessar o arquivo");
                tb.Clear();
            }
            return l;
        }
        
        public int leHEXA_sem_formatação(TextBox tb, int offset, int quant)
        {
            int l = 0;
            try
            {

                //Lê todos os bytes do arquivo
                byte[] arquivo = File.ReadAllBytes(nomeArquivo);
                l = arquivo.Length;
                if (offset >= l)
                {
                    tb.Clear();
                    return l;
                }
                if (offset + quant > l)
                {
                    quant = l - offset;
                }
                StringBuilder sb = new StringBuilder(quant * 2);  //2 caracteres por byte em HEXA
                for (int i = offset; i < (offset + quant); i++)
                {
                    sb.AppendFormat("{0:x2}", arquivo[i]);    //Mostra em hexa
                }
                tb.Text = sb.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro ao tentar acessar o arquivo");
                tb.Clear();
            }
            return l;
        }
    
        public void leCabArquivo(DataGridView dg)
        {
            #region Formatação
            dg.ColumnCount = 6;                     //Define o número de colunas
            dg.Columns[0].Name = "#";               //Define o título do cabeçalho de cada coluna
            dg.Columns[1].Name = "Campo";
            dg.Columns[2].Name = "Bytes";
            dg.Columns[3].Name = "Valor (h)";
            dg.Columns[4].Name = "Valor (10)";
            dg.Columns[5].Name = "Descrição";
            dg.RowCount = 5;                        //Define o número de linhas
            for (int i = 0; i < dg.RowCount; i++)   //Define o texto das linhas da coluna 0
            {
                //Tabela.Linha[?].Coluna[?].Valor = valor desejado 
                dg.Rows[i].Cells[0].Value = i + 1;   //Numera linhas da tabela
            }
            dg.Rows[0].Cells[1].Value = "BfType";   //Define o texto das linhas da coluna 1
            dg.Rows[1].Cells[1].Value = "BfSize";
            dg.Rows[2].Cells[1].Value = "BfReser1";
            dg.Rows[3].Cells[1].Value = "BfReser2";
            dg.Rows[4].Cells[1].Value = "BfOffSetBits";
            dg.Rows[0].Cells[2].Value = "2";        //Define o texto das linhas da coluna 2
            dg.Rows[1].Cells[2].Value = "4";
            dg.Rows[2].Cells[2].Value = "2";
            dg.Rows[3].Cells[2].Value = "2";
            dg.Rows[4].Cells[2].Value = "4";
            dg.Rows[0].Cells[5].Value = "Assinatura do arquivo: os caracteres ASCII \"BM\" ou (42 4D)h";   //Define o texto das linhas da coluna 5
            dg.Rows[1].Cells[5].Value = "Tamanho do arquivo em Bytes";
            dg.Rows[2].Cells[5].Value = "Campo reservado 1; deve ser ZERO";
            dg.Rows[3].Cells[5].Value = "Campo reservado 2; deve ser ZERO";
            dg.Rows[4].Cells[5].Value = "Especifica o deslocamento, em bytes, para o início da área de dados";

            dg.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            #endregion

            #region Leitura do arquivo
            int l = 14;                                                 //Quantidade de bytes no cabeçalho do arquivo
            try
            {
                //Lê todos os bytes do arquivo
                byte[] arquivo = File.ReadAllBytes(nomeArquivo);
                l = arquivo.Length;
                StringBuilder sb = new StringBuilder(l * 2);            //2 caracteres por byte em HEXA
                for (int i = 0; i < 14; i++)
                {
                    sb.AppendFormat("{0:x2}", arquivo[i]);              //Mostra em hexa
                }
                string hexa = sb.ToString();
                dg.Rows[0].Cells[3].Value = hexa.Substring(0*2, 2*2);   //Define o texto das linhas da coluna 3
                dg.Rows[1].Cells[3].Value = hexa.Substring(2*2, 4*2);
                dg.Rows[2].Cells[3].Value = hexa.Substring(6*2, 2*2);
                dg.Rows[3].Cells[3].Value = hexa.Substring(8*2, 2*2);
                dg.Rows[4].Cells[3].Value = hexa.Substring(10*2,4*2);
                
                                                                        //Define o texto das linhas da coluna 4
                //Inverte a ordem dos bytes para poder converter para inteiro
                string ordem = dg.Rows[1].Cells[3].Value.ToString();    
                ordem = ordem.Substring(6, 2) + ordem.Substring(4, 2) + ordem.Substring(2, 2) + ordem.Substring(0, 2);
                dg.Rows[1].Cells[4].Value = Convert.ToInt32(ordem, 16);
                
                ordem = dg.Rows[2].Cells[3].Value.ToString();
                ordem = ordem.Substring(2, 2) + ordem.Substring(0, 2);
                dg.Rows[2].Cells[4].Value = Convert.ToInt32(ordem, 16);
                
                ordem = dg.Rows[3].Cells[3].Value.ToString();
                ordem = ordem.Substring(2, 2) + ordem.Substring(0, 2);
                dg.Rows[3].Cells[4].Value = Convert.ToInt32(ordem, 16);
                
                ordem = dg.Rows[4].Cells[3].Value.ToString();
                ordem = ordem.Substring(6, 2) + ordem.Substring(4, 2) + ordem.Substring(2, 2) + ordem.Substring(0, 2);
                dg.Rows[4].Cells[4].Value = Convert.ToInt32(ordem, 16);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro ao tentar acessar o arquivo");
            }
            #endregion
        }

        public void leCabMapaDeBits(DataGridView dg)
        {
            #region Formatação
            dg.ColumnCount = 6;                     //Define o número de colunas
            dg.Columns[0].Name = "#";               //Define o título do cabeçalho de cada coluna
            dg.Columns[1].Name = "Campo";
            dg.Columns[2].Name = "Bytes";
            dg.Columns[3].Name = "Valor (h)";
            dg.Columns[4].Name = "Valor (10)";
            dg.Columns[5].Name = "Descrição";
            dg.RowCount = 11;                       //Define o número de linhas
            for (int i = 0; i < dg.RowCount; i++)   //Define o texto das linhas da coluna 0
            {
                //Tabela.Linha[?].Coluna[?].Valor = valor desejado 
                dg.Rows[i].Cells[0].Value = i + 1;   //Numera linhas da tabela
            }
            dg.Rows[0].Cells[1].Value = "BiSize";   //Define o texto das linhas da coluna 1
            dg.Rows[1].Cells[1].Value = "BiWidth";
            dg.Rows[2].Cells[1].Value = "BiHeight";
            dg.Rows[3].Cells[1].Value = "BiPlanes";
            dg.Rows[4].Cells[1].Value = "BiBitCount";
            dg.Rows[5].Cells[1].Value = "BiCompress";
            dg.Rows[6].Cells[1].Value = "BiSizeImag";
            dg.Rows[7].Cells[1].Value = "BiXPPMeter";
            dg.Rows[8].Cells[1].Value = "BiYPPMeter";
            dg.Rows[9].Cells[1].Value = "BiClrUsed";
            dg.Rows[10].Cells[1].Value = "BiClrImpor";
            dg.Rows[0].Cells[2].Value = "4";        //Define o texto das linhas da coluna 2
            dg.Rows[1].Cells[2].Value = "4";
            dg.Rows[2].Cells[2].Value = "4";
            dg.Rows[3].Cells[2].Value = "2";
            dg.Rows[4].Cells[2].Value = "2";
            dg.Rows[5].Cells[2].Value = "4";
            dg.Rows[6].Cells[2].Value = "4";
            dg.Rows[7].Cells[2].Value = "4";
            dg.Rows[8].Cells[2].Value = "4";
            dg.Rows[9].Cells[2].Value = "4";
            dg.Rows[10].Cells[2].Value = "4";
            dg.Rows[0].Cells[5].Value = "Tamanho deste cabeçalho (40 bytes). Sempre (28)h.";   //Define o texto das linhas da coluna 5
            dg.Rows[1].Cells[5].Value = "Largura da imagem em pixels";
            dg.Rows[2].Cells[5].Value = "Altura da imagem em pixels";
            dg.Rows[3].Cells[5].Value = "Número de planos de imagem. Sempre 1";
            dg.Rows[4].Cells[5].Value = "Quantidade de Bits por pixel (1,4,8,24,32)";
            dg.Rows[5].Cells[5].Value = "Compressão usada. Pode ser: 0 = BI_RGB sem compressão; 1 = BI_RLE8 compressão RLE 8 bits; 2 = BI_RLE4 compressão RLE 4 bits";
            dg.Rows[6].Cells[5].Value = "Tamanho da imagem (dados) em byte";
            dg.Rows[7].Cells[5].Value = "Resolução horizontal em pixels por metro";
            dg.Rows[8].Cells[5].Value = "Resolução vertical em pixels por metro";
            dg.Rows[9].Cells[5].Value = "Número de cores usadas na imagem. Quando ZERO indica o uso do máximo de cores possível.";
            dg.Rows[10].Cells[5].Value = "Número de cores importantes (realmente usadas) na imagem. Se todas são importantes pode ser ZERO.";
            
            dg.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            #endregion

            #region Leitura do arquivo
            int l = 40;                                                 //Quantidade de bytes no cabeçalho do arquivo
            int offset = 14;                                            //Posição do primeiro byte
            try
            {
                //Lê todos os bytes do arquivo
                byte[] arquivo = File.ReadAllBytes(nomeArquivo);
                l = arquivo.Length;
                StringBuilder sb = new StringBuilder(l * 2);            //2 caracteres por byte em HEXA
                for (int i = 0; i < 40; i++)
                {
                    sb.AppendFormat("{0:x2}", arquivo[i + offset]);     //Mostra em hexa
                }
                string hexa = sb.ToString();
                dg.Rows[0].Cells[3].Value = hexa.Substring(0 * 2, 4 * 2);   //Define o texto das linhas da coluna 3
                dg.Rows[1].Cells[3].Value = hexa.Substring(4 * 2, 4 * 2);
                dg.Rows[2].Cells[3].Value = hexa.Substring(8 * 2, 4 * 2);
                dg.Rows[3].Cells[3].Value = hexa.Substring(12 * 2, 2 * 2);
                dg.Rows[4].Cells[3].Value = hexa.Substring(14 * 2, 2 * 2);
                dg.Rows[5].Cells[3].Value = hexa.Substring(16 * 2, 4 * 2);
                dg.Rows[6].Cells[3].Value = hexa.Substring(20 * 2, 4 * 2);
                dg.Rows[7].Cells[3].Value = hexa.Substring(24 * 2, 4 * 2);
                dg.Rows[8].Cells[3].Value = hexa.Substring(28 * 2, 4 * 2);
                dg.Rows[9].Cells[3].Value = hexa.Substring(32 * 2, 4 * 2);
                dg.Rows[10].Cells[3].Value = hexa.Substring(36 * 2, 4 * 2);

                                                                            //Define o texto das linhas da coluna 4
                //Inverte a ordem dos bytes para poder converter para inteiro
                string ordem = dg.Rows[0].Cells[3].Value.ToString();
                ordem = ordem.Substring(6, 2) + ordem.Substring(4, 2) + ordem.Substring(2, 2) + ordem.Substring(0, 2);
                dg.Rows[0].Cells[4].Value = Convert.ToInt32(ordem, 16);

                ordem = dg.Rows[1].Cells[3].Value.ToString();
                ordem = ordem.Substring(6, 2) + ordem.Substring(4, 2) + ordem.Substring(2, 2) + ordem.Substring(0, 2);
                dg.Rows[1].Cells[4].Value = Convert.ToInt32(ordem, 16);

                ordem = dg.Rows[2].Cells[3].Value.ToString();
                ordem = ordem.Substring(6, 2) + ordem.Substring(4, 2) + ordem.Substring(2, 2) + ordem.Substring(0, 2);
                dg.Rows[2].Cells[4].Value = Convert.ToInt32(ordem, 16);

                ordem = dg.Rows[3].Cells[3].Value.ToString();
                ordem = ordem.Substring(2, 2) + ordem.Substring(0, 2);
                dg.Rows[3].Cells[4].Value = Convert.ToInt32(ordem, 16);

                ordem = dg.Rows[4].Cells[3].Value.ToString();
                ordem = ordem.Substring(2, 2) + ordem.Substring(0, 2);
                dg.Rows[4].Cells[4].Value = Convert.ToInt32(ordem, 16);

                ordem = dg.Rows[5].Cells[3].Value.ToString();
                ordem = ordem.Substring(6, 2) + ordem.Substring(4, 2) + ordem.Substring(2, 2) + ordem.Substring(0, 2);
                dg.Rows[5].Cells[4].Value = Convert.ToInt32(ordem, 16);

                ordem = dg.Rows[6].Cells[3].Value.ToString();
                ordem = ordem.Substring(6, 2) + ordem.Substring(4, 2) + ordem.Substring(2, 2) + ordem.Substring(0, 2);
                dg.Rows[6].Cells[4].Value = Convert.ToInt32(ordem, 16);

                ordem = dg.Rows[7].Cells[3].Value.ToString();
                ordem = ordem.Substring(6, 2) + ordem.Substring(4, 2) + ordem.Substring(2, 2) + ordem.Substring(0, 2);
                dg.Rows[7].Cells[4].Value = Convert.ToInt32(ordem, 16);

                ordem = dg.Rows[8].Cells[3].Value.ToString();
                ordem = ordem.Substring(6, 2) + ordem.Substring(4, 2) + ordem.Substring(2, 2) + ordem.Substring(0, 2);
                dg.Rows[8].Cells[4].Value = Convert.ToInt32(ordem, 16);

                ordem = dg.Rows[9].Cells[3].Value.ToString();
                ordem = ordem.Substring(6, 2) + ordem.Substring(4, 2) + ordem.Substring(2, 2) + ordem.Substring(0, 2);
                dg.Rows[9].Cells[4].Value = Convert.ToInt32(ordem, 16);
                
                ordem = dg.Rows[10].Cells[3].Value.ToString();
                ordem = ordem.Substring(6, 2) + ordem.Substring(4, 2) + ordem.Substring(2, 2) + ordem.Substring(0, 2);
                dg.Rows[10].Cells[4].Value = Convert.ToInt32(ordem, 16);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro ao tentar acessar o arquivo");
            }

            #endregion
        }

        public void lePaletaDeCores(DataGridView dg)
        {
            #region Formatação
            dg.ColumnCount = 6;                     //Define o número de colunas
            dg.Columns[0].Name = "#";               //Define o título do cabeçalho de cada coluna
            dg.Columns[1].Name = "Campo";
            dg.Columns[2].Name = "Bytes";
            dg.Columns[3].Name = "Valor (h)";
            dg.Columns[4].Name = "Valor (10)";
            dg.Columns[5].Name = "Descrição";

            dg.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            #endregion

            #region Leitura do arquivo
            int offset = 54;                                                        //Posição do primeiro byte
            try
            {
                //Lê todos os bytes do arquivo
                byte[] arquivo = File.ReadAllBytes(nomeArquivo);
                int cores = (int)(arquivo[49]<<24) + (int)(arquivo[48]<<16) + (int)(arquivo[47]<<8) + (int)arquivo[46];   //Quantidade de cores / número de linhas da tabela
                int bits = (int)(arquivo[29] << 8) + (int)arquivo[28];                //Quantidade de bits por cor
                if (bits <= 8)                                                      //Se é até 8 bits/pixel
                {
                    if (cores == 0)                                                 //Se são todos as cores utilizadas
                        cores = (int)Math.Pow(2, bits);
                    int l = cores * 4;                                              //Quantidade de bytes de cor
                    dg.RowCount = cores;                                            //Define o número de linhas
 
                    for (int i = 0; i < cores; i++)                                 //Define o texto das linhas da coluna 0
                    {
                        //Tabela.Linha[?].Coluna[?].Valor = valor desejado 
                        dg.Rows[i].Cells[0].Value = i + 1;                          //Numera linhas da tabela
                        dg.Rows[i].Cells[1].Value = "Cor " + (i + 1).ToString();    //Define o texto das linhas da coluna 1
                        dg.Rows[i].Cells[2].Value = 4;                              //Define o texto das linhas da coluna 2
                        dg.Rows[i].Cells[5].Value = "Red-Gren-Blue-Reservado";      //Define o texto das linhas da coluna 5
                    }

                    StringBuilder sb = new StringBuilder(l * 2);                    //2 caracteres por byte em HEXA
                    for (int i = 0; i < l; i++)
                    {
                        sb.AppendFormat("{0:x2}", arquivo[i + offset]);             //Mostra em hexa
                    }
                    string hexa = sb.ToString();

                    for (int i = 0; i < cores; i++)
                    {
                        dg.Rows[i].Cells[3].Value = hexa.Substring(i * (4 * 2), 4 * 2);       //Define o texto das linhas da coluna 3                    
                    }

                    for (int i = 0; i < cores; i++)
                    {                                                               //Define o texto das linhas da coluna 4
                        byte r = arquivo[i * 4 + offset];
                        byte g = arquivo[i * 4 + offset + 1];
                        byte b = arquivo[i * 4 + offset + 2];
                        byte res = arquivo[i * 4 + offset + 3];
                        dg.Rows[i].Cells[4].Value = r.ToString() + "-" + g.ToString() + "-" + b.ToString() + "-" + res.ToString();
                    }
                }
                else
                {
                    dg.Rows.Clear();
                    dg.RowCount = 1;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro ao tentar acessar o arquivo");
            }
            #endregion
        }
    }
}
