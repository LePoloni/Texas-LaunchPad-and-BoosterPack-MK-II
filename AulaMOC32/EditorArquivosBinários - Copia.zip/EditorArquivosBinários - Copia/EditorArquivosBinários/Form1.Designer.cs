﻿namespace EditorArquivosBinários
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.arquivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.abrirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salvarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salvarComoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bPlay = new System.Windows.Forms.Button();
            this.tbAberto = new System.Windows.Forms.TextBox();
            this.bLer = new System.Windows.Forms.Button();
            this.tbTamanho = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbBytes = new System.Windows.Forms.TextBox();
            this.bDados = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.tbInicio = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tcWAVE = new System.Windows.Forms.TabControl();
            this.tpCabeçalho = new System.Windows.Forms.TabPage();
            this.dgCabeçalho = new System.Windows.Forms.DataGridView();
            this.Column0 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbCabeçalho = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tpDados = new System.Windows.Forms.TabPage();
            this.bProx = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tbDados = new System.Windows.Forms.TextBox();
            this.tbQTB = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tpMontarCab = new System.Windows.Forms.TabPage();
            this.tbSizeDataDecimal = new System.Windows.Forms.TextBox();
            this.lSizeData = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.lTamanho = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.bMontaCab = new System.Windows.Forms.Button();
            this.cbCanais = new System.Windows.Forms.ComboBox();
            this.cbTxAm = new System.Windows.Forms.ComboBox();
            this.cbNbits = new System.Windows.Forms.ComboBox();
            this.tbSizeData = new System.Windows.Forms.TextBox();
            this.tbQminima = new System.Windows.Forms.TextBox();
            this.tbNbits = new System.Windows.Forms.TextBox();
            this.tbTxAm = new System.Windows.Forms.TextBox();
            this.tbCanais = new System.Windows.Forms.TextBox();
            this.tbTmedia = new System.Windows.Forms.TextBox();
            this.tbMark = new System.Windows.Forms.TextBox();
            this.tbTam = new System.Windows.Forms.TextBox();
            this.tbRIFF = new System.Windows.Forms.TextBox();
            this.tbWAVEfmt = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.tbEstrutura = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.lQminima = new System.Windows.Forms.Label();
            this.lTmedia = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.tbMontaCabeçalho = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tpMontarDados = new System.Windows.Forms.TabPage();
            this.pbOnda = new System.Windows.Forms.PictureBox();
            this.trackBarAmplitude = new System.Windows.Forms.TrackBar();
            this.cbFormaDeOnda = new System.Windows.Forms.ComboBox();
            this.lAmplitude = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.tbTxAm2 = new System.Windows.Forms.TextBox();
            this.tbCanais2 = new System.Windows.Forms.TextBox();
            this.tbNbits2 = new System.Windows.Forms.TextBox();
            this.tbQminima2 = new System.Windows.Forms.TextBox();
            this.tbTmedia2 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.bAtualizar = new System.Windows.Forms.Button();
            this.bClear = new System.Windows.Forms.Button();
            this.bMontarDados = new System.Windows.Forms.Button();
            this.tbTotalBytes = new System.Windows.Forms.TextBox();
            this.tbTempo = new System.Windows.Forms.TextBox();
            this.tbPontos = new System.Windows.Forms.TextBox();
            this.tbCiclos = new System.Windows.Forms.TextBox();
            this.tbFreq = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.tbMontaDados = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.tpDocumentação = new System.Windows.Forms.TabPage();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.tcGeral = new System.Windows.Forms.TabControl();
            this.tpWAVE = new System.Windows.Forms.TabPage();
            this.tpBMP = new System.Windows.Forms.TabPage();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tpBMPC = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tpCab1 = new System.Windows.Forms.TabPage();
            this.label65 = new System.Windows.Forms.Label();
            this.tbCab1 = new System.Windows.Forms.TextBox();
            this.dgCab1 = new System.Windows.Forms.DataGridView();
            this.tpCab2 = new System.Windows.Forms.TabPage();
            this.label66 = new System.Windows.Forms.Label();
            this.tbCab2 = new System.Windows.Forms.TextBox();
            this.dgCab2 = new System.Windows.Forms.DataGridView();
            this.tpPaleta = new System.Windows.Forms.TabPage();
            this.label67 = new System.Windows.Forms.Label();
            this.tbPaleta = new System.Windows.Forms.TextBox();
            this.dgPaleta = new System.Windows.Forms.DataGridView();
            this.tpBMPD = new System.Windows.Forms.TabPage();
            this.label63 = new System.Windows.Forms.Label();
            this.tbBMP = new System.Windows.Forms.TextBox();
            this.bBMPProx = new System.Windows.Forms.Button();
            this.tbBMPInicio = new System.Windows.Forms.TextBox();
            this.tbBMPBytes = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.tbBMPQTB = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.bBMPLer = new System.Windows.Forms.Button();
            this.label64 = new System.Windows.Forms.Label();
            this.tpBMPI = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbZoom = new System.Windows.Forms.RadioButton();
            this.rbCentralizar = new System.Windows.Forms.RadioButton();
            this.rbEsticar = new System.Windows.Forms.RadioButton();
            this.rbNormal = new System.Windows.Forms.RadioButton();
            this.pbBMP = new System.Windows.Forms.PictureBox();
            this.tpTXT = new System.Windows.Forms.TabPage();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tpASCII = new System.Windows.Forms.TabPage();
            this.tbASCII = new System.Windows.Forms.TextBox();
            this.tpHEXA = new System.Windows.Forms.TabPage();
            this.bHEXAProx = new System.Windows.Forms.Button();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.bHEXALer = new System.Windows.Forms.Button();
            this.tbHEXA = new System.Windows.Forms.TextBox();
            this.tbHEXAQTB = new System.Windows.Forms.TextBox();
            this.tbHEXABytes = new System.Windows.Forms.TextBox();
            this.tbHEXAInicio = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.tpMIX = new System.Windows.Forms.TabPage();
            this.bMIXProx = new System.Windows.Forms.Button();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.bMIXDados = new System.Windows.Forms.Button();
            this.tbMIXQTB = new System.Windows.Forms.TextBox();
            this.tbMIXBytes = new System.Windows.Forms.TextBox();
            this.tbMIXInicio = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.tbMIXASCII = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.tbMIXHEXA = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.bMontarFull = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.tcWAVE.SuspendLayout();
            this.tpCabeçalho.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgCabeçalho)).BeginInit();
            this.tpDados.SuspendLayout();
            this.tpMontarCab.SuspendLayout();
            this.tpMontarDados.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbOnda)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarAmplitude)).BeginInit();
            this.tpDocumentação.SuspendLayout();
            this.tcGeral.SuspendLayout();
            this.tpWAVE.SuspendLayout();
            this.tpBMP.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tpBMPC.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tpCab1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgCab1)).BeginInit();
            this.tpCab2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgCab2)).BeginInit();
            this.tpPaleta.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgPaleta)).BeginInit();
            this.tpBMPD.SuspendLayout();
            this.tpBMPI.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbBMP)).BeginInit();
            this.tpTXT.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tpASCII.SuspendLayout();
            this.tpHEXA.SuspendLayout();
            this.tpMIX.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.arquivoToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(884, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // arquivoToolStripMenuItem
            // 
            this.arquivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.abrirToolStripMenuItem,
            this.salvarToolStripMenuItem,
            this.salvarComoToolStripMenuItem});
            this.arquivoToolStripMenuItem.Name = "arquivoToolStripMenuItem";
            this.arquivoToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.arquivoToolStripMenuItem.Text = "Arquivo";
            // 
            // abrirToolStripMenuItem
            // 
            this.abrirToolStripMenuItem.Name = "abrirToolStripMenuItem";
            this.abrirToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.abrirToolStripMenuItem.Text = "Abrir";
            this.abrirToolStripMenuItem.Click += new System.EventHandler(this.abrirToolStripMenuItem_Click);
            // 
            // salvarToolStripMenuItem
            // 
            this.salvarToolStripMenuItem.Name = "salvarToolStripMenuItem";
            this.salvarToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.salvarToolStripMenuItem.Text = "Salvar (Montado)";
            this.salvarToolStripMenuItem.Click += new System.EventHandler(this.salvarToolStripMenuItem_Click);
            // 
            // salvarComoToolStripMenuItem
            // 
            this.salvarComoToolStripMenuItem.Name = "salvarComoToolStripMenuItem";
            this.salvarComoToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.salvarComoToolStripMenuItem.Text = "Salvar como (Montado)";
            this.salvarComoToolStripMenuItem.Click += new System.EventHandler(this.salvarComoToolStripMenuItem_Click);
            // 
            // bPlay
            // 
            this.bPlay.Location = new System.Drawing.Point(6, 6);
            this.bPlay.Name = "bPlay";
            this.bPlay.Size = new System.Drawing.Size(75, 23);
            this.bPlay.TabIndex = 2;
            this.bPlay.Text = "Play WAVE";
            this.bPlay.UseVisualStyleBackColor = true;
            this.bPlay.Click += new System.EventHandler(this.bPlay_Click);
            // 
            // tbAberto
            // 
            this.tbAberto.Location = new System.Drawing.Point(141, 36);
            this.tbAberto.Name = "tbAberto";
            this.tbAberto.Size = new System.Drawing.Size(519, 20);
            this.tbAberto.TabIndex = 3;
            this.tbAberto.Text = "Sons\\chimes.wav";
            // 
            // bLer
            // 
            this.bLer.Location = new System.Drawing.Point(87, 6);
            this.bLer.Name = "bLer";
            this.bLer.Size = new System.Drawing.Size(75, 23);
            this.bLer.TabIndex = 4;
            this.bLer.Text = "Ler WAVE";
            this.bLer.UseVisualStyleBackColor = true;
            this.bLer.Click += new System.EventHandler(this.bLer_Click);
            // 
            // tbTamanho
            // 
            this.tbTamanho.Location = new System.Drawing.Point(141, 62);
            this.tbTamanho.Name = "tbTamanho";
            this.tbTamanho.Size = new System.Drawing.Size(80, 20);
            this.tbTamanho.TabIndex = 3;
            this.tbTamanho.Text = "0";
            this.tbTamanho.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Tamanho em Bytes";
            // 
            // tbBytes
            // 
            this.tbBytes.Location = new System.Drawing.Point(686, 33);
            this.tbBytes.Name = "tbBytes";
            this.tbBytes.Size = new System.Drawing.Size(80, 20);
            this.tbBytes.TabIndex = 3;
            this.tbBytes.Text = "200";
            this.tbBytes.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // bDados
            // 
            this.bDados.Location = new System.Drawing.Point(772, 6);
            this.bDados.Name = "bDados";
            this.bDados.Size = new System.Drawing.Size(74, 23);
            this.bDados.TabIndex = 4;
            this.bDados.Text = "Ler Dados";
            this.bDados.UseVisualStyleBackColor = true;
            this.bDados.Click += new System.EventHandler(this.bDados_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(620, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Pos. Inícial";
            // 
            // tbInicio
            // 
            this.tbInicio.Location = new System.Drawing.Point(686, 7);
            this.tbInicio.Name = "tbInicio";
            this.tbInicio.Size = new System.Drawing.Size(80, 20);
            this.tbInicio.TabIndex = 3;
            this.tbInicio.Text = "44";
            this.tbInicio.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(612, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Quant. Bytes";
            // 
            // tcWAVE
            // 
            this.tcWAVE.Controls.Add(this.tpCabeçalho);
            this.tcWAVE.Controls.Add(this.tpDados);
            this.tcWAVE.Controls.Add(this.tpMontarCab);
            this.tcWAVE.Controls.Add(this.tpMontarDados);
            this.tcWAVE.Controls.Add(this.tpDocumentação);
            this.tcWAVE.Location = new System.Drawing.Point(3, 40);
            this.tcWAVE.Name = "tcWAVE";
            this.tcWAVE.SelectedIndex = 0;
            this.tcWAVE.Size = new System.Drawing.Size(860, 450);
            this.tcWAVE.TabIndex = 6;
            // 
            // tpCabeçalho
            // 
            this.tpCabeçalho.Controls.Add(this.dgCabeçalho);
            this.tpCabeçalho.Controls.Add(this.label6);
            this.tpCabeçalho.Controls.Add(this.label4);
            this.tpCabeçalho.Controls.Add(this.tbCabeçalho);
            this.tpCabeçalho.Controls.Add(this.label5);
            this.tpCabeçalho.Location = new System.Drawing.Point(4, 22);
            this.tpCabeçalho.Name = "tpCabeçalho";
            this.tpCabeçalho.Padding = new System.Windows.Forms.Padding(3);
            this.tpCabeçalho.Size = new System.Drawing.Size(852, 424);
            this.tpCabeçalho.TabIndex = 0;
            this.tpCabeçalho.Text = "Cabeçalho";
            this.tpCabeçalho.UseVisualStyleBackColor = true;
            // 
            // dgCabeçalho
            // 
            this.dgCabeçalho.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgCabeçalho.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgCabeçalho.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column0,
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6});
            this.dgCabeçalho.Location = new System.Drawing.Point(395, 12);
            this.dgCabeçalho.Name = "dgCabeçalho";
            this.dgCabeçalho.Size = new System.Drawing.Size(451, 389);
            this.dgCabeçalho.TabIndex = 4;
            // 
            // Column0
            // 
            this.Column0.HeaderText = "#";
            this.Column0.Name = "Column0";
            this.Column0.Width = 39;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Campo";
            this.Column1.Name = "Column1";
            this.Column1.Width = 65;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Posição";
            this.Column2.Name = "Column2";
            this.Column2.Width = 70;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Tamanho";
            this.Column3.Name = "Column3";
            this.Column3.Width = 77;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "ASCII";
            this.Column4.Name = "Column4";
            this.Column4.Width = 59;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "HEXA";
            this.Column5.Name = "Column5";
            this.Column5.Width = 61;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Decimal";
            this.Column6.Name = "Column6";
            this.Column6.Width = 70;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Blue;
            this.label6.Location = new System.Drawing.Point(35, 6);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(333, 76);
            this.label6.TabIndex = 3;
            this.label6.Text = "Formado pelos primeiros 44 bytes do arquivo. Abaixo representados em hexadecimal." +
    "";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Lucida Console", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DimGray;
            this.label4.Location = new System.Drawing.Point(37, 92);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(332, 27);
            this.label4.TabIndex = 2;
            this.label4.Text = "00010203040506070809";
            // 
            // tbCabeçalho
            // 
            this.tbCabeçalho.BackColor = System.Drawing.Color.Gold;
            this.tbCabeçalho.Font = new System.Drawing.Font("Lucida Console", 20.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbCabeçalho.Location = new System.Drawing.Point(38, 124);
            this.tbCabeçalho.Multiline = true;
            this.tbCabeçalho.Name = "tbCabeçalho";
            this.tbCabeçalho.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tbCabeçalho.Size = new System.Drawing.Size(344, 277);
            this.tbCabeçalho.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Lucida Console", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DimGray;
            this.label5.Location = new System.Drawing.Point(-1, 127);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 274);
            this.label5.TabIndex = 2;
            this.label5.Text = "00102030405060708090";
            // 
            // tpDados
            // 
            this.tpDados.Controls.Add(this.bProx);
            this.tpDados.Controls.Add(this.label7);
            this.tpDados.Controls.Add(this.label10);
            this.tpDados.Controls.Add(this.label3);
            this.tpDados.Controls.Add(this.label2);
            this.tpDados.Controls.Add(this.label9);
            this.tpDados.Controls.Add(this.bDados);
            this.tpDados.Controls.Add(this.tbDados);
            this.tpDados.Controls.Add(this.tbQTB);
            this.tpDados.Controls.Add(this.tbBytes);
            this.tpDados.Controls.Add(this.tbInicio);
            this.tpDados.Controls.Add(this.label8);
            this.tpDados.Location = new System.Drawing.Point(4, 22);
            this.tpDados.Name = "tpDados";
            this.tpDados.Padding = new System.Windows.Forms.Padding(3);
            this.tpDados.Size = new System.Drawing.Size(852, 424);
            this.tpDados.TabIndex = 1;
            this.tpDados.Text = "Dados";
            this.tpDados.UseVisualStyleBackColor = true;
            // 
            // bProx
            // 
            this.bProx.Location = new System.Drawing.Point(772, 31);
            this.bProx.Name = "bProx";
            this.bProx.Size = new System.Drawing.Size(74, 23);
            this.bProx.TabIndex = 8;
            this.bProx.Text = "Ler Próx.";
            this.bProx.UseVisualStyleBackColor = true;
            this.bProx.Click += new System.EventHandler(this.bProx_Click);
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Blue;
            this.label7.Location = new System.Drawing.Point(68, 6);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(333, 76);
            this.label7.TabIndex = 7;
            this.label7.Text = "Os dados iniciam no byte 44 e se estendem até o final do arquivo.";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(585, 62);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(95, 13);
            this.label10.TabIndex = 5;
            this.label10.Text = "Quant. Total Bytes";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Lucida Console", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DimGray;
            this.label9.Location = new System.Drawing.Point(98, 111);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(652, 27);
            this.label9.TabIndex = 5;
            this.label9.Text = "0001020304050607080910111213141516171819";
            // 
            // tbDados
            // 
            this.tbDados.BackColor = System.Drawing.Color.Gold;
            this.tbDados.Font = new System.Drawing.Font("Lucida Console", 20.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbDados.Location = new System.Drawing.Point(101, 141);
            this.tbDados.Multiline = true;
            this.tbDados.Name = "tbDados";
            this.tbDados.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tbDados.Size = new System.Drawing.Size(665, 277);
            this.tbDados.TabIndex = 4;
            // 
            // tbQTB
            // 
            this.tbQTB.BackColor = System.Drawing.Color.Silver;
            this.tbQTB.Location = new System.Drawing.Point(686, 59);
            this.tbQTB.Name = "tbQTB";
            this.tbQTB.Size = new System.Drawing.Size(80, 20);
            this.tbQTB.TabIndex = 3;
            this.tbQTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Lucida Console", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DimGray;
            this.label8.Location = new System.Drawing.Point(45, 144);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 274);
            this.label8.TabIndex = 6;
            this.label8.Text = " 00  20  40  60  80 100120140160180";
            // 
            // tpMontarCab
            // 
            this.tpMontarCab.Controls.Add(this.tbSizeDataDecimal);
            this.tpMontarCab.Controls.Add(this.lSizeData);
            this.tpMontarCab.Controls.Add(this.label71);
            this.tpMontarCab.Controls.Add(this.lTamanho);
            this.tpMontarCab.Controls.Add(this.label69);
            this.tpMontarCab.Controls.Add(this.bMontaCab);
            this.tpMontarCab.Controls.Add(this.cbCanais);
            this.tpMontarCab.Controls.Add(this.cbTxAm);
            this.tpMontarCab.Controls.Add(this.cbNbits);
            this.tpMontarCab.Controls.Add(this.tbSizeData);
            this.tpMontarCab.Controls.Add(this.tbQminima);
            this.tpMontarCab.Controls.Add(this.tbNbits);
            this.tpMontarCab.Controls.Add(this.tbTxAm);
            this.tpMontarCab.Controls.Add(this.tbCanais);
            this.tpMontarCab.Controls.Add(this.tbTmedia);
            this.tpMontarCab.Controls.Add(this.tbMark);
            this.tpMontarCab.Controls.Add(this.tbTam);
            this.tpMontarCab.Controls.Add(this.tbRIFF);
            this.tpMontarCab.Controls.Add(this.tbWAVEfmt);
            this.tpMontarCab.Controls.Add(this.label22);
            this.tpMontarCab.Controls.Add(this.tbEstrutura);
            this.tpMontarCab.Controls.Add(this.label46);
            this.tpMontarCab.Controls.Add(this.label45);
            this.tpMontarCab.Controls.Add(this.label27);
            this.tpMontarCab.Controls.Add(this.lQminima);
            this.tpMontarCab.Controls.Add(this.lTmedia);
            this.tpMontarCab.Controls.Add(this.label47);
            this.tpMontarCab.Controls.Add(this.label39);
            this.tpMontarCab.Controls.Add(this.label25);
            this.tpMontarCab.Controls.Add(this.label21);
            this.tpMontarCab.Controls.Add(this.label24);
            this.tpMontarCab.Controls.Add(this.label19);
            this.tpMontarCab.Controls.Add(this.label23);
            this.tpMontarCab.Controls.Add(this.label20);
            this.tpMontarCab.Controls.Add(this.label18);
            this.tpMontarCab.Controls.Add(this.label26);
            this.tpMontarCab.Controls.Add(this.label17);
            this.tpMontarCab.Controls.Add(this.label16);
            this.tpMontarCab.Controls.Add(this.label15);
            this.tpMontarCab.Controls.Add(this.label14);
            this.tpMontarCab.Controls.Add(this.label11);
            this.tpMontarCab.Controls.Add(this.label13);
            this.tpMontarCab.Controls.Add(this.tbMontaCabeçalho);
            this.tpMontarCab.Controls.Add(this.label12);
            this.tpMontarCab.Location = new System.Drawing.Point(4, 22);
            this.tpMontarCab.Name = "tpMontarCab";
            this.tpMontarCab.Size = new System.Drawing.Size(852, 424);
            this.tpMontarCab.TabIndex = 3;
            this.tpMontarCab.Text = "Montar Cabeçalho";
            this.tpMontarCab.UseVisualStyleBackColor = true;
            // 
            // tbSizeDataDecimal
            // 
            this.tbSizeDataDecimal.Location = new System.Drawing.Point(357, 392);
            this.tbSizeDataDecimal.Name = "tbSizeDataDecimal";
            this.tbSizeDataDecimal.Size = new System.Drawing.Size(71, 20);
            this.tbSizeDataDecimal.TabIndex = 16;
            this.tbSizeDataDecimal.Text = "0";
            // 
            // lSizeData
            // 
            this.lSizeData.AutoSize = true;
            this.lSizeData.Location = new System.Drawing.Point(317, 395);
            this.lSizeData.Name = "lSizeData";
            this.lSizeData.Size = new System.Drawing.Size(13, 13);
            this.lSizeData.TabIndex = 14;
            this.lSizeData.Text = "=";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(220, 395);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(69, 13);
            this.label71.TabIndex = 15;
            this.label71.Text = "(Total dados)";
            // 
            // lTamanho
            // 
            this.lTamanho.AutoSize = true;
            this.lTamanho.Location = new System.Drawing.Point(317, 107);
            this.lTamanho.Name = "lTamanho";
            this.lTamanho.Size = new System.Drawing.Size(22, 13);
            this.lTamanho.TabIndex = 12;
            this.lTamanho.Text = "= ?";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(220, 107);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(80, 13);
            this.label69.TabIndex = 13;
            this.label69.Text = "(Total - 8 bytes)";
            // 
            // bMontaCab
            // 
            this.bMontaCab.Location = new System.Drawing.Point(310, 17);
            this.bMontaCab.Name = "bMontaCab";
            this.bMontaCab.Size = new System.Drawing.Size(118, 23);
            this.bMontaCab.TabIndex = 11;
            this.bMontaCab.Text = "Montar Cabeçalho";
            this.bMontaCab.UseVisualStyleBackColor = true;
            this.bMontaCab.Click += new System.EventHandler(this.bMontaCab_Click);
            // 
            // cbCanais
            // 
            this.cbCanais.FormattingEnabled = true;
            this.cbCanais.Items.AddRange(new object[] {
            "1 - Mono",
            "2 - Estéreo"});
            this.cbCanais.Location = new System.Drawing.Point(223, 200);
            this.cbCanais.Name = "cbCanais";
            this.cbCanais.Size = new System.Drawing.Size(121, 21);
            this.cbCanais.TabIndex = 10;
            // 
            // cbTxAm
            // 
            this.cbTxAm.FormattingEnabled = true;
            this.cbTxAm.Items.AddRange(new object[] {
            "5.000 Hz",
            "11.025 Hz",
            "22.050 Hz",
            "32.000 Hz",
            "44.100 Hz"});
            this.cbTxAm.Location = new System.Drawing.Point(223, 232);
            this.cbTxAm.Name = "cbTxAm";
            this.cbTxAm.Size = new System.Drawing.Size(121, 21);
            this.cbTxAm.TabIndex = 10;
            // 
            // cbNbits
            // 
            this.cbNbits.FormattingEnabled = true;
            this.cbNbits.Items.AddRange(new object[] {
            "8 bits",
            "16 bits"});
            this.cbNbits.Location = new System.Drawing.Point(223, 328);
            this.cbNbits.Name = "cbNbits";
            this.cbNbits.Size = new System.Drawing.Size(121, 21);
            this.cbNbits.TabIndex = 10;
            // 
            // tbSizeData
            // 
            this.tbSizeData.Enabled = false;
            this.tbSizeData.Location = new System.Drawing.Point(93, 392);
            this.tbSizeData.Name = "tbSizeData";
            this.tbSizeData.Size = new System.Drawing.Size(121, 20);
            this.tbSizeData.TabIndex = 9;
            this.tbSizeData.Text = "00000000";
            // 
            // tbQminima
            // 
            this.tbQminima.Enabled = false;
            this.tbQminima.Location = new System.Drawing.Point(93, 296);
            this.tbQminima.Name = "tbQminima";
            this.tbQminima.Size = new System.Drawing.Size(121, 20);
            this.tbQminima.TabIndex = 9;
            // 
            // tbNbits
            // 
            this.tbNbits.Enabled = false;
            this.tbNbits.Location = new System.Drawing.Point(93, 328);
            this.tbNbits.Name = "tbNbits";
            this.tbNbits.Size = new System.Drawing.Size(121, 20);
            this.tbNbits.TabIndex = 9;
            // 
            // tbTxAm
            // 
            this.tbTxAm.Enabled = false;
            this.tbTxAm.Location = new System.Drawing.Point(93, 232);
            this.tbTxAm.Name = "tbTxAm";
            this.tbTxAm.Size = new System.Drawing.Size(121, 20);
            this.tbTxAm.TabIndex = 9;
            // 
            // tbCanais
            // 
            this.tbCanais.Enabled = false;
            this.tbCanais.Location = new System.Drawing.Point(93, 200);
            this.tbCanais.Name = "tbCanais";
            this.tbCanais.Size = new System.Drawing.Size(121, 20);
            this.tbCanais.TabIndex = 9;
            // 
            // tbTmedia
            // 
            this.tbTmedia.Enabled = false;
            this.tbTmedia.Location = new System.Drawing.Point(93, 264);
            this.tbTmedia.Name = "tbTmedia";
            this.tbTmedia.Size = new System.Drawing.Size(121, 20);
            this.tbTmedia.TabIndex = 9;
            // 
            // tbMark
            // 
            this.tbMark.Enabled = false;
            this.tbMark.Location = new System.Drawing.Point(93, 360);
            this.tbMark.Name = "tbMark";
            this.tbMark.Size = new System.Drawing.Size(121, 20);
            this.tbMark.TabIndex = 9;
            this.tbMark.Text = "64617461";
            // 
            // tbTam
            // 
            this.tbTam.Enabled = false;
            this.tbTam.Location = new System.Drawing.Point(93, 104);
            this.tbTam.Name = "tbTam";
            this.tbTam.Size = new System.Drawing.Size(121, 20);
            this.tbTam.TabIndex = 9;
            this.tbTam.Text = "24000000";
            // 
            // tbRIFF
            // 
            this.tbRIFF.Enabled = false;
            this.tbRIFF.Location = new System.Drawing.Point(93, 72);
            this.tbRIFF.Name = "tbRIFF";
            this.tbRIFF.Size = new System.Drawing.Size(121, 20);
            this.tbRIFF.TabIndex = 9;
            this.tbRIFF.Text = "52494646";
            // 
            // tbWAVEfmt
            // 
            this.tbWAVEfmt.Enabled = false;
            this.tbWAVEfmt.Location = new System.Drawing.Point(93, 136);
            this.tbWAVEfmt.Name = "tbWAVEfmt";
            this.tbWAVEfmt.Size = new System.Drawing.Size(121, 20);
            this.tbWAVEfmt.TabIndex = 9;
            this.tbWAVEfmt.Text = "57415645666D7420";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(14, 299);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(47, 13);
            this.label22.TabIndex = 8;
            this.label22.Text = "Qminima";
            // 
            // tbEstrutura
            // 
            this.tbEstrutura.Enabled = false;
            this.tbEstrutura.Location = new System.Drawing.Point(93, 168);
            this.tbEstrutura.Name = "tbEstrutura";
            this.tbEstrutura.Size = new System.Drawing.Size(121, 20);
            this.tbEstrutura.TabIndex = 9;
            this.tbEstrutura.Text = "0100";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(220, 139);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(69, 13);
            this.label46.TabIndex = 8;
            this.label46.Text = "(\"WAVEfmt\")";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(220, 75);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(46, 13);
            this.label45.TabIndex = 8;
            this.label45.Text = "(\"RIFF\")";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(220, 171);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(154, 13);
            this.label27.TabIndex = 8;
            this.label27.Text = "(PCM - Pulse Code Modulation)";
            // 
            // lQminima
            // 
            this.lQminima.AutoSize = true;
            this.lQminima.Location = new System.Drawing.Point(317, 299);
            this.lQminima.Name = "lQminima";
            this.lQminima.Size = new System.Drawing.Size(22, 13);
            this.lQminima.TabIndex = 8;
            this.lQminima.Text = "= ?";
            // 
            // lTmedia
            // 
            this.lTmedia.AutoSize = true;
            this.lTmedia.Location = new System.Drawing.Point(317, 267);
            this.lTmedia.Name = "lTmedia";
            this.lTmedia.Size = new System.Drawing.Size(22, 13);
            this.lTmedia.TabIndex = 8;
            this.lTmedia.Text = "= ?";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(220, 363);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(44, 13);
            this.label47.TabIndex = 8;
            this.label47.Text = "(\"data\")";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(220, 299);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(91, 13);
            this.label39.TabIndex = 8;
            this.label39.Text = "(Canais x Nbits/8)";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(220, 267);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(91, 13);
            this.label25.TabIndex = 8;
            this.label25.Text = "(TxAm x Qminima)";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(14, 267);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(42, 13);
            this.label21.TabIndex = 8;
            this.label21.Text = "Tmedia";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(14, 331);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(31, 13);
            this.label24.TabIndex = 8;
            this.label24.Text = "Nbits";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(14, 395);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(50, 13);
            this.label19.TabIndex = 8;
            this.label19.Text = "SizeData";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(14, 363);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(31, 13);
            this.label23.TabIndex = 8;
            this.label23.Text = "Mark";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(14, 235);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(77, 13);
            this.label20.TabIndex = 8;
            this.label20.Text = "TxAmostragem";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(14, 107);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(52, 13);
            this.label18.TabIndex = 8;
            this.label18.Text = "Tamanho";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(90, 52);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(59, 13);
            this.label26.TabIndex = 8;
            this.label26.Text = "MSB...LSB";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(14, 75);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(30, 13);
            this.label17.TabIndex = 8;
            this.label17.Text = "RIFF";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(14, 139);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 13);
            this.label16.TabIndex = 8;
            this.label16.Text = "WAVEfmf";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(14, 203);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(39, 13);
            this.label15.TabIndex = 8;
            this.label15.Text = "Canais";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(14, 171);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(49, 13);
            this.label14.TabIndex = 8;
            this.label14.Text = "Estrutura";
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Blue;
            this.label11.Location = new System.Drawing.Point(483, 13);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(333, 76);
            this.label11.TabIndex = 7;
            this.label11.Text = "Cabeçalho formado pelos primeiros 44 bytes do arquivo. Abaixo representados em he" +
    "xadecimal.";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Lucida Console", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.DimGray;
            this.label13.Location = new System.Drawing.Point(484, 99);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(332, 27);
            this.label13.TabIndex = 5;
            this.label13.Text = "00010203040506070809";
            // 
            // tbMontaCabeçalho
            // 
            this.tbMontaCabeçalho.BackColor = System.Drawing.Color.Gold;
            this.tbMontaCabeçalho.Font = new System.Drawing.Font("Lucida Console", 20.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbMontaCabeçalho.Location = new System.Drawing.Point(485, 131);
            this.tbMontaCabeçalho.Multiline = true;
            this.tbMontaCabeçalho.Name = "tbMontaCabeçalho";
            this.tbMontaCabeçalho.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tbMontaCabeçalho.Size = new System.Drawing.Size(344, 277);
            this.tbMontaCabeçalho.TabIndex = 4;
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Lucida Console", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.DimGray;
            this.label12.Location = new System.Drawing.Point(443, 134);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(49, 274);
            this.label12.TabIndex = 6;
            this.label12.Text = "00102030405060708090";
            // 
            // tpMontarDados
            // 
            this.tpMontarDados.Controls.Add(this.pbOnda);
            this.tpMontarDados.Controls.Add(this.trackBarAmplitude);
            this.tpMontarDados.Controls.Add(this.cbFormaDeOnda);
            this.tpMontarDados.Controls.Add(this.lAmplitude);
            this.tpMontarDados.Controls.Add(this.label41);
            this.tpMontarDados.Controls.Add(this.label40);
            this.tpMontarDados.Controls.Add(this.tbTxAm2);
            this.tpMontarDados.Controls.Add(this.tbCanais2);
            this.tpMontarDados.Controls.Add(this.tbNbits2);
            this.tpMontarDados.Controls.Add(this.tbQminima2);
            this.tpMontarDados.Controls.Add(this.tbTmedia2);
            this.tpMontarDados.Controls.Add(this.label33);
            this.tpMontarDados.Controls.Add(this.label34);
            this.tpMontarDados.Controls.Add(this.label35);
            this.tpMontarDados.Controls.Add(this.label36);
            this.tpMontarDados.Controls.Add(this.label37);
            this.tpMontarDados.Controls.Add(this.label38);
            this.tpMontarDados.Controls.Add(this.label30);
            this.tpMontarDados.Controls.Add(this.label43);
            this.tpMontarDados.Controls.Add(this.label42);
            this.tpMontarDados.Controls.Add(this.label31);
            this.tpMontarDados.Controls.Add(this.label32);
            this.tpMontarDados.Controls.Add(this.bAtualizar);
            this.tpMontarDados.Controls.Add(this.bClear);
            this.tpMontarDados.Controls.Add(this.bMontarDados);
            this.tpMontarDados.Controls.Add(this.tbTotalBytes);
            this.tpMontarDados.Controls.Add(this.tbTempo);
            this.tpMontarDados.Controls.Add(this.tbPontos);
            this.tpMontarDados.Controls.Add(this.tbCiclos);
            this.tpMontarDados.Controls.Add(this.tbFreq);
            this.tpMontarDados.Controls.Add(this.label29);
            this.tpMontarDados.Controls.Add(this.tbMontaDados);
            this.tpMontarDados.Controls.Add(this.label28);
            this.tpMontarDados.Location = new System.Drawing.Point(4, 22);
            this.tpMontarDados.Name = "tpMontarDados";
            this.tpMontarDados.Size = new System.Drawing.Size(852, 424);
            this.tpMontarDados.TabIndex = 4;
            this.tpMontarDados.Text = "Montar Dados";
            this.tpMontarDados.UseVisualStyleBackColor = true;
            // 
            // pbOnda
            // 
            this.pbOnda.BackColor = System.Drawing.Color.Black;
            this.pbOnda.Location = new System.Drawing.Point(407, 12);
            this.pbOnda.Name = "pbOnda";
            this.pbOnda.Size = new System.Drawing.Size(138, 78);
            this.pbOnda.TabIndex = 27;
            this.pbOnda.TabStop = false;
            this.pbOnda.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbOnda_MouseDown);
            this.pbOnda.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pbOnda_MouseMove);
            this.pbOnda.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbOnda_MouseUp);
            // 
            // trackBarAmplitude
            // 
            this.trackBarAmplitude.LargeChange = 10;
            this.trackBarAmplitude.Location = new System.Drawing.Point(280, 45);
            this.trackBarAmplitude.Maximum = 100;
            this.trackBarAmplitude.Minimum = 10;
            this.trackBarAmplitude.Name = "trackBarAmplitude";
            this.trackBarAmplitude.Size = new System.Drawing.Size(121, 45);
            this.trackBarAmplitude.SmallChange = 10;
            this.trackBarAmplitude.TabIndex = 26;
            this.trackBarAmplitude.Value = 100;
            this.trackBarAmplitude.Scroll += new System.EventHandler(this.trackBarAmplitude_Scroll);
            // 
            // cbFormaDeOnda
            // 
            this.cbFormaDeOnda.FormattingEnabled = true;
            this.cbFormaDeOnda.Items.AddRange(new object[] {
            "Senóide",
            "Dente de Serra",
            "Triangular",
            "Quadrada",
            "Customizada"});
            this.cbFormaDeOnda.Location = new System.Drawing.Point(280, 12);
            this.cbFormaDeOnda.Name = "cbFormaDeOnda";
            this.cbFormaDeOnda.Size = new System.Drawing.Size(121, 21);
            this.cbFormaDeOnda.TabIndex = 25;
            // 
            // lAmplitude
            // 
            this.lAmplitude.AutoSize = true;
            this.lAmplitude.Location = new System.Drawing.Point(215, 65);
            this.lAmplitude.Name = "lAmplitude";
            this.lAmplitude.Size = new System.Drawing.Size(25, 13);
            this.lAmplitude.TabIndex = 24;
            this.lAmplitude.Text = "100";
            this.lAmplitude.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(201, 48);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(70, 13);
            this.label41.TabIndex = 24;
            this.label41.Text = "Amplitude (%)";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(201, 15);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(80, 13);
            this.label40.TabIndex = 24;
            this.label40.Text = "Forma de Onda";
            // 
            // tbTxAm2
            // 
            this.tbTxAm2.Enabled = false;
            this.tbTxAm2.Location = new System.Drawing.Point(88, 45);
            this.tbTxAm2.Name = "tbTxAm2";
            this.tbTxAm2.Size = new System.Drawing.Size(61, 20);
            this.tbTxAm2.TabIndex = 23;
            // 
            // tbCanais2
            // 
            this.tbCanais2.Enabled = false;
            this.tbCanais2.Location = new System.Drawing.Point(88, 13);
            this.tbCanais2.Name = "tbCanais2";
            this.tbCanais2.Size = new System.Drawing.Size(61, 20);
            this.tbCanais2.TabIndex = 23;
            // 
            // tbNbits2
            // 
            this.tbNbits2.Enabled = false;
            this.tbNbits2.Location = new System.Drawing.Point(88, 140);
            this.tbNbits2.Name = "tbNbits2";
            this.tbNbits2.Size = new System.Drawing.Size(61, 20);
            this.tbNbits2.TabIndex = 23;
            // 
            // tbQminima2
            // 
            this.tbQminima2.Enabled = false;
            this.tbQminima2.Location = new System.Drawing.Point(88, 109);
            this.tbQminima2.Name = "tbQminima2";
            this.tbQminima2.Size = new System.Drawing.Size(61, 20);
            this.tbQminima2.TabIndex = 23;
            // 
            // tbTmedia2
            // 
            this.tbTmedia2.Enabled = false;
            this.tbTmedia2.Location = new System.Drawing.Point(88, 77);
            this.tbTmedia2.Name = "tbTmedia2";
            this.tbTmedia2.Size = new System.Drawing.Size(61, 20);
            this.tbTmedia2.TabIndex = 23;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(9, 112);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(47, 13);
            this.label33.TabIndex = 21;
            this.label33.Text = "Qminima";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(215, 94);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(91, 13);
            this.label34.TabIndex = 22;
            this.label34.Text = "(TxAm x Qminima)";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(9, 80);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(42, 13);
            this.label35.TabIndex = 20;
            this.label35.Text = "Tmedia";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(9, 144);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(31, 13);
            this.label36.TabIndex = 18;
            this.label36.Text = "Nbits";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(9, 48);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(77, 13);
            this.label37.TabIndex = 19;
            this.label37.Text = "TxAmostragem";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(9, 16);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(39, 13);
            this.label38.TabIndex = 17;
            this.label38.Text = "Canais";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(551, 68);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(95, 13);
            this.label30.TabIndex = 14;
            this.label30.Text = "Quant. Total Bytes";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(720, 68);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(54, 13);
            this.label43.TabIndex = 15;
            this.label43.Text = "Tempo (s)";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(734, 42);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(40, 13);
            this.label42.TabIndex = 15;
            this.label42.Text = "Pontos";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(611, 42);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(35, 13);
            this.label31.TabIndex = 15;
            this.label31.Text = "Ciclos";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(586, 16);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(60, 13);
            this.label32.TabIndex = 16;
            this.label32.Text = "Frequência";
            // 
            // bAtualizar
            // 
            this.bAtualizar.Location = new System.Drawing.Point(12, 166);
            this.bAtualizar.Name = "bAtualizar";
            this.bAtualizar.Size = new System.Drawing.Size(137, 23);
            this.bAtualizar.TabIndex = 13;
            this.bAtualizar.Text = "Atualizar";
            this.bAtualizar.UseVisualStyleBackColor = true;
            this.bAtualizar.Click += new System.EventHandler(this.bAtualizar_Click);
            // 
            // bClear
            // 
            this.bClear.Location = new System.Drawing.Point(407, 89);
            this.bClear.Name = "bClear";
            this.bClear.Size = new System.Drawing.Size(138, 23);
            this.bClear.TabIndex = 13;
            this.bClear.Text = "Clear";
            this.bClear.UseVisualStyleBackColor = true;
            this.bClear.Click += new System.EventHandler(this.bClear_Click);
            // 
            // bMontarDados
            // 
            this.bMontarDados.Location = new System.Drawing.Point(738, 12);
            this.bMontarDados.Name = "bMontarDados";
            this.bMontarDados.Size = new System.Drawing.Size(99, 23);
            this.bMontarDados.TabIndex = 13;
            this.bMontarDados.Text = "Montar Dados";
            this.bMontarDados.UseVisualStyleBackColor = true;
            this.bMontarDados.Click += new System.EventHandler(this.bMontarDados_Click);
            // 
            // tbTotalBytes
            // 
            this.tbTotalBytes.BackColor = System.Drawing.SystemColors.Window;
            this.tbTotalBytes.Enabled = false;
            this.tbTotalBytes.Location = new System.Drawing.Point(652, 65);
            this.tbTotalBytes.Name = "tbTotalBytes";
            this.tbTotalBytes.Size = new System.Drawing.Size(62, 20);
            this.tbTotalBytes.TabIndex = 10;
            this.tbTotalBytes.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbTempo
            // 
            this.tbTempo.Enabled = false;
            this.tbTempo.Location = new System.Drawing.Point(781, 65);
            this.tbTempo.Name = "tbTempo";
            this.tbTempo.Size = new System.Drawing.Size(56, 20);
            this.tbTempo.TabIndex = 11;
            this.tbTempo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbPontos
            // 
            this.tbPontos.Enabled = false;
            this.tbPontos.Location = new System.Drawing.Point(781, 39);
            this.tbPontos.Name = "tbPontos";
            this.tbPontos.Size = new System.Drawing.Size(56, 20);
            this.tbPontos.TabIndex = 11;
            this.tbPontos.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbCiclos
            // 
            this.tbCiclos.Location = new System.Drawing.Point(652, 39);
            this.tbCiclos.Name = "tbCiclos";
            this.tbCiclos.Size = new System.Drawing.Size(62, 20);
            this.tbCiclos.TabIndex = 11;
            this.tbCiclos.Text = "200";
            this.tbCiclos.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbFreq
            // 
            this.tbFreq.Location = new System.Drawing.Point(652, 13);
            this.tbFreq.Name = "tbFreq";
            this.tbFreq.Size = new System.Drawing.Size(62, 20);
            this.tbFreq.TabIndex = 12;
            this.tbFreq.Text = "1000";
            this.tbFreq.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Lucida Console", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.DimGray;
            this.label29.Location = new System.Drawing.Point(181, 114);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(652, 27);
            this.label29.TabIndex = 8;
            this.label29.Text = "0001020304050607080910111213141516171819";
            // 
            // tbMontaDados
            // 
            this.tbMontaDados.BackColor = System.Drawing.Color.Gold;
            this.tbMontaDados.Font = new System.Drawing.Font("Lucida Console", 20.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbMontaDados.Location = new System.Drawing.Point(184, 144);
            this.tbMontaDados.Multiline = true;
            this.tbMontaDados.Name = "tbMontaDados";
            this.tbMontaDados.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tbMontaDados.Size = new System.Drawing.Size(665, 277);
            this.tbMontaDados.TabIndex = 7;
            // 
            // label28
            // 
            this.label28.Font = new System.Drawing.Font("Lucida Console", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.DimGray;
            this.label28.Location = new System.Drawing.Point(128, 147);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(61, 274);
            this.label28.TabIndex = 9;
            this.label28.Text = " 00  20  40  60  80 100120140160180 ";
            // 
            // tpDocumentação
            // 
            this.tpDocumentação.Controls.Add(this.textBox3);
            this.tpDocumentação.Location = new System.Drawing.Point(4, 22);
            this.tpDocumentação.Name = "tpDocumentação";
            this.tpDocumentação.Size = new System.Drawing.Size(852, 424);
            this.tpDocumentação.TabIndex = 2;
            this.tpDocumentação.Text = "Documentação";
            this.tpDocumentação.UseVisualStyleBackColor = true;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.Gold;
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(3, 3);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox3.Size = new System.Drawing.Size(846, 418);
            this.textBox3.TabIndex = 1;
            this.textBox3.Text = resources.GetString("textBox3.Text");
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(13, 39);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(122, 13);
            this.label44.TabIndex = 5;
            this.label44.Text = "Arquivo Aberto ou Salvo";
            // 
            // tcGeral
            // 
            this.tcGeral.Controls.Add(this.tpWAVE);
            this.tcGeral.Controls.Add(this.tpBMP);
            this.tcGeral.Controls.Add(this.tpTXT);
            this.tcGeral.Location = new System.Drawing.Point(0, 99);
            this.tcGeral.Name = "tcGeral";
            this.tcGeral.SelectedIndex = 0;
            this.tcGeral.Size = new System.Drawing.Size(872, 550);
            this.tcGeral.TabIndex = 7;
            // 
            // tpWAVE
            // 
            this.tpWAVE.Controls.Add(this.tcWAVE);
            this.tpWAVE.Controls.Add(this.bPlay);
            this.tpWAVE.Controls.Add(this.bLer);
            this.tpWAVE.Controls.Add(this.bMontarFull);
            this.tpWAVE.Location = new System.Drawing.Point(4, 22);
            this.tpWAVE.Name = "tpWAVE";
            this.tpWAVE.Padding = new System.Windows.Forms.Padding(3);
            this.tpWAVE.Size = new System.Drawing.Size(864, 524);
            this.tpWAVE.TabIndex = 0;
            this.tpWAVE.Text = "WAVE";
            this.tpWAVE.UseVisualStyleBackColor = true;
            // 
            // tpBMP
            // 
            this.tpBMP.Controls.Add(this.tabControl3);
            this.tpBMP.Location = new System.Drawing.Point(4, 22);
            this.tpBMP.Name = "tpBMP";
            this.tpBMP.Padding = new System.Windows.Forms.Padding(3);
            this.tpBMP.Size = new System.Drawing.Size(864, 524);
            this.tpBMP.TabIndex = 1;
            this.tpBMP.Text = "BMP";
            this.tpBMP.UseVisualStyleBackColor = true;
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tpBMPC);
            this.tabControl3.Controls.Add(this.tpBMPD);
            this.tabControl3.Controls.Add(this.tpBMPI);
            this.tabControl3.Location = new System.Drawing.Point(8, 16);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(850, 502);
            this.tabControl3.TabIndex = 31;
            // 
            // tpBMPC
            // 
            this.tpBMPC.Controls.Add(this.tabControl2);
            this.tpBMPC.Location = new System.Drawing.Point(4, 22);
            this.tpBMPC.Name = "tpBMPC";
            this.tpBMPC.Padding = new System.Windows.Forms.Padding(3);
            this.tpBMPC.Size = new System.Drawing.Size(842, 476);
            this.tpBMPC.TabIndex = 0;
            this.tpBMPC.Text = "Cabeçalho";
            this.tpBMPC.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tpCab1);
            this.tabControl2.Controls.Add(this.tpCab2);
            this.tabControl2.Controls.Add(this.tpPaleta);
            this.tabControl2.Location = new System.Drawing.Point(25, 75);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(811, 395);
            this.tabControl2.TabIndex = 32;
            // 
            // tpCab1
            // 
            this.tpCab1.Controls.Add(this.label65);
            this.tpCab1.Controls.Add(this.tbCab1);
            this.tpCab1.Controls.Add(this.dgCab1);
            this.tpCab1.Location = new System.Drawing.Point(4, 22);
            this.tpCab1.Name = "tpCab1";
            this.tpCab1.Padding = new System.Windows.Forms.Padding(3);
            this.tpCab1.Size = new System.Drawing.Size(803, 369);
            this.tpCab1.TabIndex = 0;
            this.tpCab1.Text = "Cabeçalho de Arquivo";
            this.tpCab1.UseVisualStyleBackColor = true;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(8, 14);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(106, 13);
            this.label65.TabIndex = 42;
            this.label65.Text = "Quantidade de Bytes";
            // 
            // tbCab1
            // 
            this.tbCab1.BackColor = System.Drawing.Color.Silver;
            this.tbCab1.Location = new System.Drawing.Point(120, 11);
            this.tbCab1.Name = "tbCab1";
            this.tbCab1.Size = new System.Drawing.Size(80, 20);
            this.tbCab1.TabIndex = 41;
            this.tbCab1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // dgCab1
            // 
            this.dgCab1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgCab1.Location = new System.Drawing.Point(6, 41);
            this.dgCab1.Name = "dgCab1";
            this.dgCab1.Size = new System.Drawing.Size(791, 322);
            this.dgCab1.TabIndex = 0;
            // 
            // tpCab2
            // 
            this.tpCab2.Controls.Add(this.label66);
            this.tpCab2.Controls.Add(this.tbCab2);
            this.tpCab2.Controls.Add(this.dgCab2);
            this.tpCab2.Location = new System.Drawing.Point(4, 22);
            this.tpCab2.Name = "tpCab2";
            this.tpCab2.Padding = new System.Windows.Forms.Padding(3);
            this.tpCab2.Size = new System.Drawing.Size(803, 369);
            this.tpCab2.TabIndex = 1;
            this.tpCab2.Text = "Cabeçalho de Mapa de Bits";
            this.tpCab2.UseVisualStyleBackColor = true;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(8, 14);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(106, 13);
            this.label66.TabIndex = 44;
            this.label66.Text = "Quantidade de Bytes";
            // 
            // tbCab2
            // 
            this.tbCab2.BackColor = System.Drawing.Color.Silver;
            this.tbCab2.Location = new System.Drawing.Point(120, 11);
            this.tbCab2.Name = "tbCab2";
            this.tbCab2.Size = new System.Drawing.Size(80, 20);
            this.tbCab2.TabIndex = 43;
            this.tbCab2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // dgCab2
            // 
            this.dgCab2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgCab2.Location = new System.Drawing.Point(6, 42);
            this.dgCab2.Name = "dgCab2";
            this.dgCab2.Size = new System.Drawing.Size(791, 321);
            this.dgCab2.TabIndex = 1;
            // 
            // tpPaleta
            // 
            this.tpPaleta.Controls.Add(this.label67);
            this.tpPaleta.Controls.Add(this.tbPaleta);
            this.tpPaleta.Controls.Add(this.dgPaleta);
            this.tpPaleta.Location = new System.Drawing.Point(4, 22);
            this.tpPaleta.Name = "tpPaleta";
            this.tpPaleta.Size = new System.Drawing.Size(803, 369);
            this.tpPaleta.TabIndex = 2;
            this.tpPaleta.Text = "Paleta de Cores";
            this.tpPaleta.UseVisualStyleBackColor = true;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(8, 14);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(104, 13);
            this.label67.TabIndex = 46;
            this.label67.Text = "Quantdade de Bytes";
            // 
            // tbPaleta
            // 
            this.tbPaleta.BackColor = System.Drawing.Color.Silver;
            this.tbPaleta.Location = new System.Drawing.Point(118, 11);
            this.tbPaleta.Name = "tbPaleta";
            this.tbPaleta.Size = new System.Drawing.Size(80, 20);
            this.tbPaleta.TabIndex = 45;
            this.tbPaleta.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // dgPaleta
            // 
            this.dgPaleta.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgPaleta.Location = new System.Drawing.Point(6, 42);
            this.dgPaleta.Name = "dgPaleta";
            this.dgPaleta.Size = new System.Drawing.Size(794, 324);
            this.dgPaleta.TabIndex = 1;
            // 
            // tpBMPD
            // 
            this.tpBMPD.Controls.Add(this.label63);
            this.tpBMPD.Controls.Add(this.tbBMP);
            this.tpBMPD.Controls.Add(this.bBMPProx);
            this.tpBMPD.Controls.Add(this.tbBMPInicio);
            this.tpBMPD.Controls.Add(this.tbBMPBytes);
            this.tpBMPD.Controls.Add(this.label60);
            this.tpBMPD.Controls.Add(this.tbBMPQTB);
            this.tpBMPD.Controls.Add(this.label61);
            this.tpBMPD.Controls.Add(this.label62);
            this.tpBMPD.Controls.Add(this.bBMPLer);
            this.tpBMPD.Controls.Add(this.label64);
            this.tpBMPD.Location = new System.Drawing.Point(4, 22);
            this.tpBMPD.Name = "tpBMPD";
            this.tpBMPD.Padding = new System.Windows.Forms.Padding(3);
            this.tpBMPD.Size = new System.Drawing.Size(842, 476);
            this.tpBMPD.TabIndex = 1;
            this.tpBMPD.Text = "Dados";
            this.tpBMPD.UseVisualStyleBackColor = true;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Lucida Console", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.ForeColor = System.Drawing.Color.DimGray;
            this.label63.Location = new System.Drawing.Point(114, 140);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(652, 27);
            this.label63.TabIndex = 46;
            this.label63.Text = "0001020304050607080910111213141516171819";
            // 
            // tbBMP
            // 
            this.tbBMP.BackColor = System.Drawing.Color.Gold;
            this.tbBMP.Font = new System.Drawing.Font("Lucida Console", 20.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbBMP.Location = new System.Drawing.Point(117, 170);
            this.tbBMP.Multiline = true;
            this.tbBMP.Name = "tbBMP";
            this.tbBMP.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tbBMP.Size = new System.Drawing.Size(665, 277);
            this.tbBMP.TabIndex = 39;
            // 
            // bBMPProx
            // 
            this.bBMPProx.Location = new System.Drawing.Point(708, 54);
            this.bBMPProx.Name = "bBMPProx";
            this.bBMPProx.Size = new System.Drawing.Size(74, 23);
            this.bBMPProx.TabIndex = 48;
            this.bBMPProx.Text = "Ler Próx.";
            this.bBMPProx.UseVisualStyleBackColor = true;
            this.bBMPProx.Click += new System.EventHandler(this.bBMPProx_Click);
            // 
            // tbBMPInicio
            // 
            this.tbBMPInicio.Location = new System.Drawing.Point(623, 30);
            this.tbBMPInicio.Name = "tbBMPInicio";
            this.tbBMPInicio.Size = new System.Drawing.Size(80, 20);
            this.tbBMPInicio.TabIndex = 35;
            this.tbBMPInicio.Text = "0";
            this.tbBMPInicio.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbBMPBytes
            // 
            this.tbBMPBytes.Location = new System.Drawing.Point(623, 56);
            this.tbBMPBytes.Name = "tbBMPBytes";
            this.tbBMPBytes.Size = new System.Drawing.Size(80, 20);
            this.tbBMPBytes.TabIndex = 33;
            this.tbBMPBytes.Text = "200";
            this.tbBMPBytes.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(522, 85);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(95, 13);
            this.label60.TabIndex = 40;
            this.label60.Text = "Quant. Total Bytes";
            // 
            // tbBMPQTB
            // 
            this.tbBMPQTB.BackColor = System.Drawing.Color.Silver;
            this.tbBMPQTB.Location = new System.Drawing.Point(623, 82);
            this.tbBMPQTB.Name = "tbBMPQTB";
            this.tbBMPQTB.Size = new System.Drawing.Size(80, 20);
            this.tbBMPQTB.TabIndex = 32;
            this.tbBMPQTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(549, 59);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(68, 13);
            this.label61.TabIndex = 43;
            this.label61.Text = "Quant. Bytes";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(557, 33);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(60, 13);
            this.label62.TabIndex = 44;
            this.label62.Text = "Pos. Inícial";
            // 
            // bBMPLer
            // 
            this.bBMPLer.Location = new System.Drawing.Point(708, 28);
            this.bBMPLer.Name = "bBMPLer";
            this.bBMPLer.Size = new System.Drawing.Size(74, 23);
            this.bBMPLer.TabIndex = 37;
            this.bBMPLer.Text = "Ler Dados";
            this.bBMPLer.UseVisualStyleBackColor = true;
            this.bBMPLer.Click += new System.EventHandler(this.bBMPLer_Click);
            // 
            // label64
            // 
            this.label64.Font = new System.Drawing.Font("Lucida Console", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.ForeColor = System.Drawing.Color.DimGray;
            this.label64.Location = new System.Drawing.Point(60, 173);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(61, 274);
            this.label64.TabIndex = 47;
            this.label64.Text = " 00  20  40  60  80 100120140160180";
            // 
            // tpBMPI
            // 
            this.tpBMPI.Controls.Add(this.groupBox1);
            this.tpBMPI.Controls.Add(this.pbBMP);
            this.tpBMPI.Location = new System.Drawing.Point(4, 22);
            this.tpBMPI.Name = "tpBMPI";
            this.tpBMPI.Size = new System.Drawing.Size(842, 476);
            this.tpBMPI.TabIndex = 2;
            this.tpBMPI.Text = "Imagem";
            this.tpBMPI.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbZoom);
            this.groupBox1.Controls.Add(this.rbCentralizar);
            this.groupBox1.Controls.Add(this.rbEsticar);
            this.groupBox1.Controls.Add(this.rbNormal);
            this.groupBox1.Location = new System.Drawing.Point(676, 33);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(127, 115);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Modo de Visualização";
            // 
            // rbZoom
            // 
            this.rbZoom.AutoSize = true;
            this.rbZoom.Location = new System.Drawing.Point(6, 88);
            this.rbZoom.Name = "rbZoom";
            this.rbZoom.Size = new System.Drawing.Size(52, 17);
            this.rbZoom.TabIndex = 3;
            this.rbZoom.Text = "Zoom";
            this.rbZoom.UseVisualStyleBackColor = true;
            this.rbZoom.CheckedChanged += new System.EventHandler(this.rbZoom_CheckedChanged);
            // 
            // rbCentralizar
            // 
            this.rbCentralizar.AutoSize = true;
            this.rbCentralizar.Location = new System.Drawing.Point(6, 65);
            this.rbCentralizar.Name = "rbCentralizar";
            this.rbCentralizar.Size = new System.Drawing.Size(74, 17);
            this.rbCentralizar.TabIndex = 2;
            this.rbCentralizar.Text = "Centralizar";
            this.rbCentralizar.UseVisualStyleBackColor = true;
            this.rbCentralizar.CheckedChanged += new System.EventHandler(this.rbCentralizar_CheckedChanged);
            // 
            // rbEsticar
            // 
            this.rbEsticar.AutoSize = true;
            this.rbEsticar.Location = new System.Drawing.Point(6, 42);
            this.rbEsticar.Name = "rbEsticar";
            this.rbEsticar.Size = new System.Drawing.Size(57, 17);
            this.rbEsticar.TabIndex = 1;
            this.rbEsticar.Text = "Esticar";
            this.rbEsticar.UseVisualStyleBackColor = true;
            this.rbEsticar.CheckedChanged += new System.EventHandler(this.rbEsticar_CheckedChanged);
            // 
            // rbNormal
            // 
            this.rbNormal.AutoSize = true;
            this.rbNormal.Checked = true;
            this.rbNormal.Location = new System.Drawing.Point(6, 19);
            this.rbNormal.Name = "rbNormal";
            this.rbNormal.Size = new System.Drawing.Size(58, 17);
            this.rbNormal.TabIndex = 0;
            this.rbNormal.TabStop = true;
            this.rbNormal.Text = "Normal";
            this.rbNormal.UseVisualStyleBackColor = true;
            this.rbNormal.CheckedChanged += new System.EventHandler(this.rbNormal_CheckedChanged);
            // 
            // pbBMP
            // 
            this.pbBMP.BackColor = System.Drawing.Color.Black;
            this.pbBMP.Location = new System.Drawing.Point(44, 33);
            this.pbBMP.Name = "pbBMP";
            this.pbBMP.Size = new System.Drawing.Size(600, 400);
            this.pbBMP.TabIndex = 0;
            this.pbBMP.TabStop = false;
            // 
            // tpTXT
            // 
            this.tpTXT.Controls.Add(this.tabControl1);
            this.tpTXT.Location = new System.Drawing.Point(4, 22);
            this.tpTXT.Name = "tpTXT";
            this.tpTXT.Size = new System.Drawing.Size(864, 524);
            this.tpTXT.TabIndex = 2;
            this.tpTXT.Text = "TXT";
            this.tpTXT.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tpASCII);
            this.tabControl1.Controls.Add(this.tpHEXA);
            this.tabControl1.Controls.Add(this.tpMIX);
            this.tabControl1.Location = new System.Drawing.Point(6, 15);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(855, 506);
            this.tabControl1.TabIndex = 0;
            // 
            // tpASCII
            // 
            this.tpASCII.Controls.Add(this.tbASCII);
            this.tpASCII.Location = new System.Drawing.Point(4, 22);
            this.tpASCII.Name = "tpASCII";
            this.tpASCII.Padding = new System.Windows.Forms.Padding(3);
            this.tpASCII.Size = new System.Drawing.Size(847, 480);
            this.tpASCII.TabIndex = 0;
            this.tpASCII.Text = "ASCII";
            this.tpASCII.UseVisualStyleBackColor = true;
            // 
            // tbASCII
            // 
            this.tbASCII.BackColor = System.Drawing.Color.PaleTurquoise;
            this.tbASCII.Font = new System.Drawing.Font("Lucida Console", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbASCII.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbASCII.Location = new System.Drawing.Point(3, 6);
            this.tbASCII.Multiline = true;
            this.tbASCII.Name = "tbASCII";
            this.tbASCII.Size = new System.Drawing.Size(838, 468);
            this.tbASCII.TabIndex = 0;
            // 
            // tpHEXA
            // 
            this.tpHEXA.Controls.Add(this.bHEXAProx);
            this.tpHEXA.Controls.Add(this.label48);
            this.tpHEXA.Controls.Add(this.label49);
            this.tpHEXA.Controls.Add(this.label51);
            this.tpHEXA.Controls.Add(this.label52);
            this.tpHEXA.Controls.Add(this.bHEXALer);
            this.tpHEXA.Controls.Add(this.tbHEXA);
            this.tpHEXA.Controls.Add(this.tbHEXAQTB);
            this.tpHEXA.Controls.Add(this.tbHEXABytes);
            this.tpHEXA.Controls.Add(this.tbHEXAInicio);
            this.tpHEXA.Controls.Add(this.label50);
            this.tpHEXA.Location = new System.Drawing.Point(4, 22);
            this.tpHEXA.Name = "tpHEXA";
            this.tpHEXA.Padding = new System.Windows.Forms.Padding(3);
            this.tpHEXA.Size = new System.Drawing.Size(847, 480);
            this.tpHEXA.TabIndex = 1;
            this.tpHEXA.Text = "HEXA";
            this.tpHEXA.UseVisualStyleBackColor = true;
            // 
            // bHEXAProx
            // 
            this.bHEXAProx.Location = new System.Drawing.Point(697, 49);
            this.bHEXAProx.Name = "bHEXAProx";
            this.bHEXAProx.Size = new System.Drawing.Size(74, 23);
            this.bHEXAProx.TabIndex = 19;
            this.bHEXAProx.Text = "Ler Próx.";
            this.bHEXAProx.UseVisualStyleBackColor = true;
            this.bHEXAProx.Click += new System.EventHandler(this.bHEXAProx_Click);
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(510, 80);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(95, 13);
            this.label48.TabIndex = 14;
            this.label48.Text = "Quant. Total Bytes";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(537, 54);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(68, 13);
            this.label49.TabIndex = 15;
            this.label49.Text = "Quant. Bytes";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(545, 28);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(60, 13);
            this.label51.TabIndex = 16;
            this.label51.Text = "Pos. Inícial";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Lucida Console", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.ForeColor = System.Drawing.Color.DimGray;
            this.label52.Location = new System.Drawing.Point(103, 137);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(652, 27);
            this.label52.TabIndex = 17;
            this.label52.Text = "0001020304050607080910111213141516171819";
            // 
            // bHEXALer
            // 
            this.bHEXALer.Location = new System.Drawing.Point(697, 24);
            this.bHEXALer.Name = "bHEXALer";
            this.bHEXALer.Size = new System.Drawing.Size(74, 23);
            this.bHEXALer.TabIndex = 12;
            this.bHEXALer.Text = "Ler Dados";
            this.bHEXALer.UseVisualStyleBackColor = true;
            this.bHEXALer.Click += new System.EventHandler(this.bLerHEXA_Click);
            // 
            // tbHEXA
            // 
            this.tbHEXA.BackColor = System.Drawing.Color.Gold;
            this.tbHEXA.Font = new System.Drawing.Font("Lucida Console", 20.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbHEXA.Location = new System.Drawing.Point(106, 167);
            this.tbHEXA.Multiline = true;
            this.tbHEXA.Name = "tbHEXA";
            this.tbHEXA.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tbHEXA.Size = new System.Drawing.Size(665, 277);
            this.tbHEXA.TabIndex = 13;
            // 
            // tbHEXAQTB
            // 
            this.tbHEXAQTB.BackColor = System.Drawing.Color.Silver;
            this.tbHEXAQTB.Location = new System.Drawing.Point(611, 77);
            this.tbHEXAQTB.Name = "tbHEXAQTB";
            this.tbHEXAQTB.Size = new System.Drawing.Size(80, 20);
            this.tbHEXAQTB.TabIndex = 9;
            this.tbHEXAQTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHEXABytes
            // 
            this.tbHEXABytes.Location = new System.Drawing.Point(611, 51);
            this.tbHEXABytes.Name = "tbHEXABytes";
            this.tbHEXABytes.Size = new System.Drawing.Size(80, 20);
            this.tbHEXABytes.TabIndex = 10;
            this.tbHEXABytes.Text = "200";
            this.tbHEXABytes.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHEXAInicio
            // 
            this.tbHEXAInicio.Location = new System.Drawing.Point(611, 25);
            this.tbHEXAInicio.Name = "tbHEXAInicio";
            this.tbHEXAInicio.Size = new System.Drawing.Size(80, 20);
            this.tbHEXAInicio.TabIndex = 11;
            this.tbHEXAInicio.Text = "0";
            this.tbHEXAInicio.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label50
            // 
            this.label50.Font = new System.Drawing.Font("Lucida Console", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.ForeColor = System.Drawing.Color.DimGray;
            this.label50.Location = new System.Drawing.Point(49, 170);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(61, 274);
            this.label50.TabIndex = 18;
            this.label50.Text = " 00  20  40  60  80 100120140160180";
            // 
            // tpMIX
            // 
            this.tpMIX.Controls.Add(this.bMIXProx);
            this.tpMIX.Controls.Add(this.label57);
            this.tpMIX.Controls.Add(this.label58);
            this.tpMIX.Controls.Add(this.label59);
            this.tpMIX.Controls.Add(this.bMIXDados);
            this.tpMIX.Controls.Add(this.tbMIXQTB);
            this.tpMIX.Controls.Add(this.tbMIXBytes);
            this.tpMIX.Controls.Add(this.tbMIXInicio);
            this.tpMIX.Controls.Add(this.label56);
            this.tpMIX.Controls.Add(this.tbMIXASCII);
            this.tpMIX.Controls.Add(this.label54);
            this.tpMIX.Controls.Add(this.tbMIXHEXA);
            this.tpMIX.Controls.Add(this.label55);
            this.tpMIX.Controls.Add(this.label53);
            this.tpMIX.Location = new System.Drawing.Point(4, 22);
            this.tpMIX.Name = "tpMIX";
            this.tpMIX.Size = new System.Drawing.Size(847, 480);
            this.tpMIX.TabIndex = 2;
            this.tpMIX.Text = "MIX";
            this.tpMIX.UseVisualStyleBackColor = true;
            // 
            // bMIXProx
            // 
            this.bMIXProx.Location = new System.Drawing.Point(697, 49);
            this.bMIXProx.Name = "bMIXProx";
            this.bMIXProx.Size = new System.Drawing.Size(74, 23);
            this.bMIXProx.TabIndex = 27;
            this.bMIXProx.Text = "Ler Próx.";
            this.bMIXProx.UseVisualStyleBackColor = true;
            this.bMIXProx.Click += new System.EventHandler(this.bMIXProx_Click);
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(510, 80);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(95, 13);
            this.label57.TabIndex = 24;
            this.label57.Text = "Quant. Total Bytes";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(537, 54);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(68, 13);
            this.label58.TabIndex = 25;
            this.label58.Text = "Quant. Bytes";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(545, 28);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(60, 13);
            this.label59.TabIndex = 26;
            this.label59.Text = "Pos. Inícial";
            // 
            // bMIXDados
            // 
            this.bMIXDados.Location = new System.Drawing.Point(697, 24);
            this.bMIXDados.Name = "bMIXDados";
            this.bMIXDados.Size = new System.Drawing.Size(74, 23);
            this.bMIXDados.TabIndex = 23;
            this.bMIXDados.Text = "Ler Dados";
            this.bMIXDados.UseVisualStyleBackColor = true;
            this.bMIXDados.Click += new System.EventHandler(this.bMIXDados_Click);
            // 
            // tbMIXQTB
            // 
            this.tbMIXQTB.BackColor = System.Drawing.Color.Silver;
            this.tbMIXQTB.Location = new System.Drawing.Point(611, 77);
            this.tbMIXQTB.Name = "tbMIXQTB";
            this.tbMIXQTB.Size = new System.Drawing.Size(80, 20);
            this.tbMIXQTB.TabIndex = 20;
            this.tbMIXQTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbMIXBytes
            // 
            this.tbMIXBytes.Location = new System.Drawing.Point(611, 51);
            this.tbMIXBytes.Name = "tbMIXBytes";
            this.tbMIXBytes.Size = new System.Drawing.Size(80, 20);
            this.tbMIXBytes.TabIndex = 21;
            this.tbMIXBytes.Text = "100";
            this.tbMIXBytes.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbMIXInicio
            // 
            this.tbMIXInicio.Location = new System.Drawing.Point(611, 25);
            this.tbMIXInicio.Name = "tbMIXInicio";
            this.tbMIXInicio.Size = new System.Drawing.Size(80, 20);
            this.tbMIXInicio.TabIndex = 22;
            this.tbMIXInicio.Text = "0";
            this.tbMIXInicio.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Lucida Console", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.ForeColor = System.Drawing.Color.DimGray;
            this.label56.Location = new System.Drawing.Point(573, 115);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(229, 19);
            this.label56.TabIndex = 11;
            this.label56.Text = "01234567890123456789";
            // 
            // tbMIXASCII
            // 
            this.tbMIXASCII.BackColor = System.Drawing.Color.PaleTurquoise;
            this.tbMIXASCII.Font = new System.Drawing.Font("Lucida Console", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbMIXASCII.Location = new System.Drawing.Point(575, 137);
            this.tbMIXASCII.Multiline = true;
            this.tbMIXASCII.Name = "tbMIXASCII";
            this.tbMIXASCII.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tbMIXASCII.Size = new System.Drawing.Size(245, 320);
            this.tbMIXASCII.TabIndex = 10;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Lucida Console", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.ForeColor = System.Drawing.Color.DimGray;
            this.label54.Location = new System.Drawing.Point(58, 115);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(449, 19);
            this.label54.TabIndex = 8;
            this.label54.Text = "0001020304050607080910111213141516171819";
            // 
            // tbMIXHEXA
            // 
            this.tbMIXHEXA.BackColor = System.Drawing.Color.Gold;
            this.tbMIXHEXA.Font = new System.Drawing.Font("Lucida Console", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbMIXHEXA.Location = new System.Drawing.Point(60, 137);
            this.tbMIXHEXA.Multiline = true;
            this.tbMIXHEXA.Name = "tbMIXHEXA";
            this.tbMIXHEXA.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tbMIXHEXA.Size = new System.Drawing.Size(468, 320);
            this.tbMIXHEXA.TabIndex = 7;
            // 
            // label55
            // 
            this.label55.Font = new System.Drawing.Font("Lucida Console", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.ForeColor = System.Drawing.Color.DimGray;
            this.label55.Location = new System.Drawing.Point(535, 137);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(45, 333);
            this.label55.TabIndex = 12;
            this.label55.Text = " 00  20  40  60  80  90 100120140160180200220240260280300";
            // 
            // label53
            // 
            this.label53.Font = new System.Drawing.Font("Lucida Console", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.ForeColor = System.Drawing.Color.DimGray;
            this.label53.Location = new System.Drawing.Point(20, 138);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(42, 332);
            this.label53.TabIndex = 9;
            this.label53.Text = " 00  20  40  60  80  90 100120140160180200220240260280300";
            // 
            // bMontarFull
            // 
            this.bMontarFull.Location = new System.Drawing.Point(168, 6);
            this.bMontarFull.Name = "bMontarFull";
            this.bMontarFull.Size = new System.Drawing.Size(676, 23);
            this.bMontarFull.TabIndex = 13;
            this.bMontarFull.Text = "Montar WAVE Fácil (onda  = senoidal, canal = mono, taxa = 22050 Hz, bits/amostra " +
    "= 8 bits, tempo = 2 s)";
            this.bMontarFull.UseVisualStyleBackColor = true;
            this.bMontarFull.Click += new System.EventHandler(this.bMontarFull_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(884, 661);
            this.Controls.Add(this.tcGeral);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbTamanho);
            this.Controls.Add(this.tbAberto);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Editor de Arquivos Binários";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tcWAVE.ResumeLayout(false);
            this.tpCabeçalho.ResumeLayout(false);
            this.tpCabeçalho.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgCabeçalho)).EndInit();
            this.tpDados.ResumeLayout(false);
            this.tpDados.PerformLayout();
            this.tpMontarCab.ResumeLayout(false);
            this.tpMontarCab.PerformLayout();
            this.tpMontarDados.ResumeLayout(false);
            this.tpMontarDados.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbOnda)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarAmplitude)).EndInit();
            this.tpDocumentação.ResumeLayout(false);
            this.tpDocumentação.PerformLayout();
            this.tcGeral.ResumeLayout(false);
            this.tpWAVE.ResumeLayout(false);
            this.tpBMP.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tpBMPC.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tpCab1.ResumeLayout(false);
            this.tpCab1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgCab1)).EndInit();
            this.tpCab2.ResumeLayout(false);
            this.tpCab2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgCab2)).EndInit();
            this.tpPaleta.ResumeLayout(false);
            this.tpPaleta.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgPaleta)).EndInit();
            this.tpBMPD.ResumeLayout(false);
            this.tpBMPD.PerformLayout();
            this.tpBMPI.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbBMP)).EndInit();
            this.tpTXT.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tpASCII.ResumeLayout(false);
            this.tpASCII.PerformLayout();
            this.tpHEXA.ResumeLayout(false);
            this.tpHEXA.PerformLayout();
            this.tpMIX.ResumeLayout(false);
            this.tpMIX.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem arquivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem abrirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salvarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salvarComoToolStripMenuItem;
        private System.Windows.Forms.Button bPlay;
        private System.Windows.Forms.TextBox tbAberto;
        private System.Windows.Forms.Button bLer;
        private System.Windows.Forms.TextBox tbTamanho;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbBytes;
        private System.Windows.Forms.Button bDados;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbInicio;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabControl tcWAVE;
        private System.Windows.Forms.TabPage tpCabeçalho;
        private System.Windows.Forms.TabPage tpDados;
        private System.Windows.Forms.TextBox tbCabeçalho;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dgCabeçalho;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column0;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbDados;
        private System.Windows.Forms.Button bProx;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tbQTB;
        private System.Windows.Forms.TabPage tpDocumentação;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TabPage tpMontarCab;
        private System.Windows.Forms.TextBox tbWAVEfmt;
        private System.Windows.Forms.TextBox tbEstrutura;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox tbMontaCabeçalho;
        private System.Windows.Forms.ComboBox cbNbits;
        private System.Windows.Forms.TextBox tbSizeData;
        private System.Windows.Forms.TextBox tbMark;
        private System.Windows.Forms.TextBox tbTam;
        private System.Windows.Forms.TextBox tbRIFF;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox cbCanais;
        private System.Windows.Forms.ComboBox cbTxAm;
        private System.Windows.Forms.TextBox tbTmedia;
        private System.Windows.Forms.Button bMontaCab;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TabPage tpMontarDados;
        private System.Windows.Forms.TextBox tbTxAm2;
        private System.Windows.Forms.TextBox tbCanais2;
        private System.Windows.Forms.TextBox tbNbits2;
        private System.Windows.Forms.TextBox tbQminima2;
        private System.Windows.Forms.TextBox tbTmedia2;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Button bAtualizar;
        private System.Windows.Forms.Button bMontarDados;
        private System.Windows.Forms.TextBox tbTotalBytes;
        private System.Windows.Forms.TextBox tbCiclos;
        private System.Windows.Forms.TextBox tbFreq;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox tbMontaDados;
        private System.Windows.Forms.TextBox tbQminima;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.ComboBox cbFormaDeOnda;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TrackBar trackBarAmplitude;
        private System.Windows.Forms.Label lAmplitude;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.PictureBox pbOnda;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox tbTempo;
        private System.Windows.Forms.TextBox tbPontos;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox tbNbits;
        private System.Windows.Forms.TextBox tbTxAm;
        private System.Windows.Forms.TextBox tbCanais;
        private System.Windows.Forms.Label lQminima;
        private System.Windows.Forms.Label lTmedia;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Button bClear;
        private System.Windows.Forms.TabControl tcGeral;
        private System.Windows.Forms.TabPage tpWAVE;
        private System.Windows.Forms.TabPage tpBMP;
        private System.Windows.Forms.TabPage tpTXT;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tpASCII;
        private System.Windows.Forms.TextBox tbASCII;
        private System.Windows.Forms.TabPage tpHEXA;
        private System.Windows.Forms.Button bHEXAProx;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Button bHEXALer;
        private System.Windows.Forms.TextBox tbHEXA;
        private System.Windows.Forms.TextBox tbHEXAQTB;
        private System.Windows.Forms.TextBox tbHEXABytes;
        private System.Windows.Forms.TextBox tbHEXAInicio;
        private System.Windows.Forms.TabPage tpMIX;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox tbMIXASCII;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox tbMIXHEXA;
        private System.Windows.Forms.Button bMIXProx;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Button bMIXDados;
        private System.Windows.Forms.TextBox tbMIXQTB;
        private System.Windows.Forms.TextBox tbMIXBytes;
        private System.Windows.Forms.TextBox tbMIXInicio;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tpBMPC;
        private System.Windows.Forms.TabPage tpBMPD;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.TextBox tbBMP;
        private System.Windows.Forms.Button bBMPProx;
        private System.Windows.Forms.TextBox tbBMPInicio;
        private System.Windows.Forms.TextBox tbBMPBytes;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox tbBMPQTB;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Button bBMPLer;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.TabPage tpBMPI;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbZoom;
        private System.Windows.Forms.RadioButton rbCentralizar;
        private System.Windows.Forms.RadioButton rbEsticar;
        private System.Windows.Forms.RadioButton rbNormal;
        private System.Windows.Forms.PictureBox pbBMP;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tpCab1;
        private System.Windows.Forms.DataGridView dgCab1;
        private System.Windows.Forms.TabPage tpCab2;
        private System.Windows.Forms.TabPage tpPaleta;
        private System.Windows.Forms.DataGridView dgCab2;
        private System.Windows.Forms.DataGridView dgPaleta;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TextBox tbCab1;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox tbCab2;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.TextBox tbPaleta;
        private System.Windows.Forms.Label lSizeData;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label lTamanho;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.TextBox tbSizeDataDecimal;
        private System.Windows.Forms.Button bMontarFull;
    }
}

