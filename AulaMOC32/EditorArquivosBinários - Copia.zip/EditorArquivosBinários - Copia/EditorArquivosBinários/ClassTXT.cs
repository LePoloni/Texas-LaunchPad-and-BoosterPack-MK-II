﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//Incluido manualmente
using System.Windows.Forms;
using System.IO;

namespace EditorArquivosBinários
{
    public class ClassTXT
    {
        //Atributos
        string nomeArquivo;
        //Método construtor
        public ClassTXT(string nomeArq)
        {
            nomeArquivo = nomeArq;
        }
        //Métodos
        /// <summary>
        /// Lê arquivo de texto em ASCII e atualiza caixa de texto
        /// </summary>
        /// <param name="tb">caixa de texto que será atualizada passada por referência</param>
        public void leASCII(TextBox tb)
        {
            try
            {
                //Abre um arquivo para leitura
                using (StreamReader sr = File.OpenText(nomeArquivo))
                {
                    tb.Clear();
                    string s = "";
                    //Lê linha por linha até o final do arquivo
                    do
                    {
                        s = sr.ReadLine();
                        if (s != null)  //Se s não é nulo atualiza o TextBox
                            tb.Text += s + Environment.NewLine;
                    }
                    while (s != null);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro ao tentar acessar o arquivo");
                tb.Clear();
            }
        }
        /// <summary>
        /// Lê arquivo de texto em HEXA e atualiza caixa de texto
        /// </summary>
        /// <param name="tb">caixa de texto que será atualizada passada por referência</param>
        /// <returns>tamanho do arquivo em de bytes</returns>
        public int leHEXA(TextBox tb)
        {
            int l = 0;
            try
            {
                //Lê todos os bytes do arquivo
                byte[] arquivo = File.ReadAllBytes(nomeArquivo);
                l = arquivo.Length;
                StringBuilder sb = new StringBuilder(l);
                for (int i = 0; i < l; i++)
                {
                    sb.AppendFormat("{0:x2}", arquivo[i]);  //Mostra em hexa
                }
                tb.Text = sb.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro ao tentar acessar o arquivo");
                tb.Clear();
            }
            return l;
        }
        public void leASCII_sem_formatação(TextBox tb, int offset, int quant)
        {
            try
            {
                //Lê todos os bytes do arquivo
                byte[] arquivo = File.ReadAllBytes(nomeArquivo);
                int l = arquivo.Length;
                if (offset >= l)
                {
                    tb.Clear();
                    return;
                }
                if (offset + quant > l)
                {
                    quant = l - offset;
                }
                byte[] MA = new byte[quant];
                for (int i = offset; i < (offset + quant); i++)
                {
                    if (arquivo[i] < 0x20 || arquivo[i] > 0x7E)
                        MA[i-offset] = (byte)'.';
                    else
                        MA[i-offset] = arquivo[i];
                }
                tb.Text = Encoding.ASCII.GetString(MA, 0, quant);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro ao tentar acessar o arquivo");
                tb.Clear();
            }
        }
        public int leHEXA_sem_formatação(TextBox tb, int offset, int quant)
        {
            int l = 0;
            try
            {
                
                //Lê todos os bytes do arquivo
                byte[] arquivo = File.ReadAllBytes(nomeArquivo);
                l = arquivo.Length;
                if (offset >= l)
                {
                    tb.Clear();
                    return l;
                }
                if (offset + quant > l)
                {
                    quant = l - offset;
                }
                StringBuilder sb = new StringBuilder(quant*2);  //2 caracteres por byte em HEXA
                for (int i = offset; i < (offset + quant); i++)
                {
                    sb.AppendFormat("{0:x2}", arquivo[i]);    //Mostra em hexa
                }
                tb.Text = sb.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro ao tentar acessar o arquivo");
                tb.Clear();
            }
            return l;
        }

    }
}
