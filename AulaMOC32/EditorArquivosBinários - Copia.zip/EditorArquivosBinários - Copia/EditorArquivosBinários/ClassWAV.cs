﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//Incluido manualmente
using System.Windows.Forms;
using System.IO;
using System.Drawing;

namespace EditorArquivosBinários
{
    class ClassWAV
    {
        //Enumerações
        //Essa é a proposta para facilitar a configuração
        public enum Canais
        {
            mono = 1, estereo
        }
        public enum TaxaAm
        {
            Tx5000 = 5000,
            Tx11025 = 11025,
            Tx22050 = 22025,
            Tx32000 = 32000,
            Tx44100 = 44100
        }
        public enum NBits
        {
            b8 = 8, b16 = 16
        }
        public enum Onda
        {
            Senóide,
            DenteSerra,
            Triangular,
            Quadrada,
            Customizada
        }

        //Atributos
        string nomeArquivo; //Nome do arquivo
        // Variáveis comuns a montagem de um arquivo WAVE
        int iCanais;        //Número de canais
        int iTxAm;          //Taxa de amostragem (Am/s)
        int iNbits;         //Número de bits/amostra de cada canal (b/Am)
        int iQmin;          //Quatidade mínima de bytes/amostra = Canais x (Nbits/amostra) / 8
        int iTmed;          //Taxa média (B/s) = TxAm * Qmin
        int iTamDados;      //Tamanho dados

        Canais eCanais;     //Número de canais
        TaxaAm eTxAm;       //Taxa de amostragem (Am/s)
        NBits  eNbits;      //Número de bits/amostra de cada canal (b/Am)

        //Métodos construtores
        /// <summary>
        /// Método construtor para abertura de arquivo
        /// </summary>
        /// <param name="nomeArq">Nome do arquivo a ser aberto</param>
        public ClassWAV(string nomeArq)
        {
            nomeArquivo = nomeArq;

            iCanais = 0;
            iTxAm = 0;
            iNbits = 0;
            iQmin = 0;
            iTmed = 0;
            iTamDados = 0;
        }
        /// <summary>
        /// Método construtor para criação de arquivo
        /// </summary>
        /// <param name="canais">Número de canais</param>
        /// <param name="taxa">Taxa de amostragem</param>
        /// <param name="bits">Número de bits por amostragem por canal</param>
        public ClassWAV(Canais canais, TaxaAm taxa, NBits bits)
        {
            nomeArquivo = "";

            iCanais = (int)canais;
            iTxAm = (int)taxa;
            iNbits = (int)bits;
            iQmin = iCanais * iNbits / 8;
            iTmed = iTxAm * iQmin;
            iTamDados = 0;

            eCanais = canais;
            eTxAm = taxa;
            eNbits = bits;
        }
        /// <summary>
        /// Método construtor para criação de arquivo pré-definido
        /// (canal = mono, taxa = 22050 Hz, bits/amostra = 8 bits) 
        /// </summary>
        public ClassWAV()
        {
            nomeArquivo = "";

            iCanais = (int)Canais.mono;
            iTxAm = (int)TaxaAm.Tx22050;
            iNbits = (int)NBits.b8;
            iQmin = iCanais * iNbits / 8;
            iTmed = iTxAm * iQmin;
            iTamDados = 0;

            eCanais = Canais.mono;
            eTxAm = TaxaAm.Tx22050;
            eNbits = NBits.b8;
        }
        //Métodos
        /// <summary>
        /// Lê arquivo de texto em ASCII e atualiza caixa de texto
        /// </summary>
        /// <param name="tb">Caixa de texto que será atualizada passada por referência</param>
        public void leASCII(TextBox tb)
        {
            try
            {
                //Abre um arquivo para leitura
                using (StreamReader sr = File.OpenText(nomeArquivo))
                {
                    tb.Clear();
                    string s = "";
                    //Lê linha por linha até o final do arquivo
                    do
                    {
                        s = sr.ReadLine();
                        if (s != null)  //Se s não é nulo atualiza o TextBox
                            tb.Text += s + Environment.NewLine;
                    }
                    while (s != null);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro ao tentar acessar o arquivo");
                tb.Clear();
            }
        }
        /// <summary>
        /// Lê arquivo de texto em HEXA e atualiza caixa de texto
        /// </summary>
        /// <param name="tb">Caixa de texto que será atualizada passada por referência</param>
        /// <returns>Tamanho do arquivo em bytes</returns>
        public int leHEXA(TextBox tb)
        {
            int l = 0;
            try
            {
                //Lê todos os bytes do arquivo
                byte[] arquivo = File.ReadAllBytes(nomeArquivo);
                l = arquivo.Length;
                StringBuilder sb = new StringBuilder(l);
                for (int i = 0; i < l; i++)
                {
                    sb.AppendFormat("{0:x2}", arquivo[i]);  //Mostra em hexa
                }
                tb.Text = sb.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro ao tentar acessar o arquivo");
                tb.Clear();
            }
            return l;
        }
        /// <summary>
        /// Lê arquivo de texto em ASCII e atualiza caixa de texto
        /// </summary>
        /// <param name="tb">Caixa de texto que será atualizada passada por referência</param>
        /// <param name="offset">Posição de início da leitura</param>
        /// <param name="quant">Quantidade de bytes lidos</param>
        public void leASCII_sem_formatação(TextBox tb, int offset, int quant)
        {
            try
            {
                //Lê todos os bytes do arquivo
                byte[] arquivo = File.ReadAllBytes(nomeArquivo);
                int l = arquivo.Length;
                if (offset >= l)
                {
                    tb.Clear();
                    return;
                }
                if (offset + quant > l)
                {
                    quant = l - offset;
                }
                byte[] MA = new byte[quant];
                for (int i = offset; i < (offset + quant); i++)
                {
                    if (arquivo[i] < 0x20 || arquivo[i] > 0x7E)
                        MA[i - offset] = (byte)'.';
                    else
                        MA[i - offset] = arquivo[i];
                }
                tb.Text = Encoding.ASCII.GetString(MA, 0, quant);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro ao tentar acessar o arquivo");
                tb.Clear();
            }
        }
        /// <summary>
        /// Lê arquivo de texto em HEXA e atualiza caixa de texto
        /// </summary>
        /// <param name="tb">Caixa de texto que será atualizada passada por referência</param>
        /// <param name="offset">Posição de início da leitura</param>
        /// <param name="quant">Quantidade de bytes lidos</param>
        /// <returns>Tamanho do arquivo em bytes</returns>
        public int leHEXA_sem_formatação(TextBox tb, int offset, int quant)
        {
            int l = 0;
            try
            {

                //Lê todos os bytes do arquivo
                byte[] arquivo = File.ReadAllBytes(nomeArquivo);
                l = arquivo.Length;
                if (offset >= l)
                {
                    tb.Clear();
                    return l;
                }
                if (offset + quant > l)
                {
                    quant = l - offset;
                }
                StringBuilder sb = new StringBuilder(quant * 2);  //2 caracteres por byte em HEXA
                for (int i = offset; i < (offset + quant); i++)
                {
                    sb.AppendFormat("{0:x2}", arquivo[i]);    //Mostra em hexa
                }
                tb.Text = sb.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro ao tentar acessar o arquivo");
                tb.Clear();
            }
            return l;
        }
        /// <summary>
        /// Lê cabeçalho de arquivo WAVE
        /// </summary>
        /// <param name="dg">Tabela que será atualizada passada por referência</param>
        public void leCabArquivo(DataGridView dg)
        {
            #region Formatação
            dg.Rows.Clear();                        //Limpa do DataGrid
            dg.ColumnCount = 7;                     //Define o número de colunas

            dg.Columns[0].Name = "#";               //Define o título do cabeçalho de cada coluna
            dg.Columns[1].Name = "Campo";
            dg.Columns[2].Name = "Posição";
            dg.Columns[3].Name = "Tamanho";
            dg.Columns[4].Name = "ASCII";
            dg.Columns[5].Name = "HEXA";
            dg.Columns[6].Name = "Decimal";

            dg.RowCount = 12;                       //Define o número de linhas

            for (int i = 0; i < dg.RowCount; i++)   //Define o texto das linhas da coluna 0
            {
                //Tabela.Linha[?].Coluna[?].Valor = valor desejado 
                dg.Rows[i].Cells[0].Value = i + 1;  //Numera linhas da tabela
            }

            dg.Rows[0].Cells[1].Value = "RIFF";     //Define o texto das linhas da coluna 1
            dg.Rows[1].Cells[1].Value = "Tamanho";
            dg.Rows[2].Cells[1].Value = "WAVEfmt";
            dg.Rows[3].Cells[1].Value = "Nulo";
            dg.Rows[4].Cells[1].Value = "Estrutura";
            dg.Rows[5].Cells[1].Value = "Canais";
            dg.Rows[6].Cells[1].Value = "TxAmostragem";
            dg.Rows[7].Cells[1].Value = "Tmedia";
            dg.Rows[8].Cells[1].Value = "Nbits";
            dg.Rows[9].Cells[1].Value = "Mark";
            dg.Rows[10].Cells[1].Value = "SizeData";
            dg.Rows[11].Cells[1].Value = "Dados";

            dg.Rows[0].Cells[2].Value = "0";        //Define o texto das linhas da coluna 2
            dg.Rows[1].Cells[2].Value = "4";
            dg.Rows[2].Cells[2].Value = "8";
            dg.Rows[3].Cells[2].Value = "16";
            dg.Rows[4].Cells[2].Value = "20";
            dg.Rows[5].Cells[2].Value = "22";
            dg.Rows[6].Cells[2].Value = "24";
            dg.Rows[7].Cells[2].Value = "28";
            dg.Rows[8].Cells[2].Value = "32";
            dg.Rows[9].Cells[2].Value = "34";
            dg.Rows[10].Cells[2].Value = "36";
            dg.Rows[11].Cells[2].Value = "40";

            dg.Rows[0].Cells[3].Value = "4";        //Define o texto das linhas da coluna 3
            dg.Rows[1].Cells[3].Value = "4";
            dg.Rows[2].Cells[3].Value = "8";
            dg.Rows[3].Cells[3].Value = "4";
            dg.Rows[4].Cells[3].Value = "2";
            dg.Rows[5].Cells[3].Value = "2";
            dg.Rows[6].Cells[3].Value = "4";
            dg.Rows[7].Cells[3].Value = "4";
            dg.Rows[8].Cells[3].Value = "2";
            dg.Rows[9].Cells[3].Value = "2";
            dg.Rows[10].Cells[3].Value = "4";
            dg.Rows[11].Cells[3].Value = "4";

            dg.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            #endregion

            #region Leitura do arquivo
            int l = 44;                                                     //Quantidade de bytes no cabeçalho do arquivo
            try
            {
                //Lê todos os bytes do arquivo
                byte[] arquivo = File.ReadAllBytes(nomeArquivo);
                l = arquivo.Length;
                string ASCII = "";
                StringBuilder sb = new StringBuilder(l * 2);                //2 caracteres por byte em HEXA
                for (int i = 0; i < 44; i++)
                {
                    if (arquivo[i] >= 0x20 && arquivo[i] < 0x7F)
                    { ASCII += (char)arquivo[i]; }                          //Mostra em ASCII ou UNICODE
                    else
                    { ASCII += "."; }
                    sb.AppendFormat("{0:x2}", arquivo[i]);                  //Mostra em hexa
                }

                dg.Rows[0].Cells[4].Value = ASCII.Substring(0, 4);          //Define o texto das linhas da coluna 4
                dg.Rows[2].Cells[4].Value = ASCII.Substring(8, 8);
                dg.Rows[10].Cells[4].Value = ASCII.Substring(36, 4);

                string hexa = sb.ToString();
                dg.Rows[0].Cells[5].Value = hexa.Substring(0 * 2, 4 * 2);   //Define o texto das linhas da coluna 5
                dg.Rows[1].Cells[5].Value = hexa.Substring(4 * 2, 4 * 2);
                dg.Rows[2].Cells[5].Value = hexa.Substring(8 * 2, 8 * 2);
                dg.Rows[3].Cells[5].Value = hexa.Substring(16 * 2, 4 * 2);
                dg.Rows[4].Cells[5].Value = hexa.Substring(20 * 2, 2 * 2);
                dg.Rows[5].Cells[5].Value = hexa.Substring(22 * 2, 2 * 2);
                dg.Rows[6].Cells[5].Value = hexa.Substring(24 * 2, 4 * 2);
                dg.Rows[7].Cells[5].Value = hexa.Substring(28 * 2, 4 * 2);
                dg.Rows[8].Cells[5].Value = hexa.Substring(32 * 2, 2 * 2);
                dg.Rows[9].Cells[5].Value = hexa.Substring(34 * 2, 2 * 2);
                dg.Rows[10].Cells[5].Value = hexa.Substring(36 * 2, 4 * 2);
                dg.Rows[11].Cells[5].Value = hexa.Substring(40 * 2, 4 * 2);

                //Define o texto das linhas da coluna 6
                //Inverte a ordem dos bytes para poder converter para inteiro
                string ordem = dg.Rows[1].Cells[5].Value.ToString();
                ordem = ordem.Substring(6, 2) + ordem.Substring(4, 2) + ordem.Substring(2, 2) + ordem.Substring(0, 2);
                dg.Rows[1].Cells[6].Value = Convert.ToInt32(ordem, 16);

                ordem = dg.Rows[3].Cells[5].Value.ToString();
                ordem = ordem.Substring(6, 2) + ordem.Substring(4, 2) + ordem.Substring(2, 2) + ordem.Substring(0, 2);
                dg.Rows[3].Cells[6].Value = Convert.ToInt32(ordem, 16);

                ordem = dg.Rows[4].Cells[5].Value.ToString();
                ordem = ordem.Substring(2, 2) + ordem.Substring(0, 2);
                dg.Rows[4].Cells[6].Value = Convert.ToInt32(ordem, 16);

                ordem = dg.Rows[5].Cells[5].Value.ToString();
                ordem = ordem.Substring(2, 2) + ordem.Substring(0, 2);
                dg.Rows[5].Cells[6].Value = Convert.ToInt32(ordem, 16);

                ordem = dg.Rows[6].Cells[5].Value.ToString();
                ordem = ordem.Substring(6, 2) + ordem.Substring(4, 2) + ordem.Substring(2, 2) + ordem.Substring(0, 2);
                dg.Rows[6].Cells[6].Value = Convert.ToInt32(ordem, 16);

                ordem = dg.Rows[7].Cells[5].Value.ToString();
                ordem = ordem.Substring(6, 2) + ordem.Substring(4, 2) + ordem.Substring(2, 2) + ordem.Substring(0, 2);
                dg.Rows[7].Cells[6].Value = Convert.ToInt32(ordem, 16);

                ordem = dg.Rows[8].Cells[5].Value.ToString();
                ordem = ordem.Substring(2, 2) + ordem.Substring(0, 2);
                dg.Rows[8].Cells[6].Value = Convert.ToInt32(ordem, 16);

                ordem = dg.Rows[9].Cells[5].Value.ToString();
                ordem = ordem.Substring(2, 2) + ordem.Substring(0, 2);
                dg.Rows[9].Cells[6].Value = Convert.ToInt32(ordem, 16);

                ordem = dg.Rows[11].Cells[5].Value.ToString();
                ordem = ordem.Substring(6, 2) + ordem.Substring(4, 2) + ordem.Substring(2, 2) + ordem.Substring(0, 2);
                dg.Rows[11].Cells[6].Value = Convert.ToInt32(ordem, 16);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro ao tentar acessar o arquivo");
            }
            #endregion
        }
        /// <summary>
        /// Monta cabeçalho de arquivo WAVE
        /// </summary>
        /// <param name="canais">Mono ou estéreo</param>
        /// <param name="taxa">Taxa de amostragem</param>
        /// <param name="bits">Bits por amostra por canal</param>
        /// <param name="tamanho_dados">Quantidade de bytes de dados</param>
        /// <param name="campos">Matriz de strings atualizada com campos do cabeçalho em HEXA (coluna 1)
        /// e descrição (coluna 2)</param>
        /// <returns>Vetor de bytes com cabeçalho</returns>
        public byte[] montaCabArquivo(Canais canais, TaxaAm taxa, NBits bits, int tamanho_dados, out string[,] campos)
        {
            //Redefine variáveis de formatação do arquivo WAVE a ser criado
            iCanais = (int)canais;
            iTxAm = (int)taxa;
            iNbits = (int)bits;
            iQmin = iCanais * iNbits / 8;
            iTmed = iTxAm * iQmin;

            eCanais = canais;
            eTxAm = taxa;
            eNbits = bits;

            string[,] Cabeçalho = new string[12,2];
            byte[] Cab = new byte[44];
            
            //Executa o submétodo
            Cab = montaCabArquivo(tamanho_dados, out Cabeçalho);

            //Retorna matriz de strings com configurações
            campos = Cabeçalho;
            //Retorna a matriz de bytes
            return Cab;
        }
        /// <summary>
        /// Monta cabeçalho de arquivo WAVE
        /// </summary>
        /// <param name="tamanho_dados">Quantidade de bytes de dados</param>
        /// <param name="campos">Matriz de strings atualizada com campos do cabeçalho em HEXA (coluna 1)
        /// e descrição (coluna 2)</param>
        /// <returns>Vetor de bytes com cabeçalho</returns>
        public byte[] montaCabArquivo(int tamanho_dados, out string[,] campos)
        {
            string[,] Cabeçalho = new string[12,2]; //12 linhas, 2 colunas (String HEXA, Descrição)
            byte[] Cab = new byte[44];

            //0 - RIFF (4B)
            Cabeçalho[0, 0] = "52494646";
            Cabeçalho[0, 1] = "RIFF";
            Cab[0] = 0x52; Cab[1] = 0x49; Cab[2] = 0x46; Cab[3] = 0x46;
            //1 - Tamanho do arquivo - 8 bytes (RIFF + Tamanho) (8B)
            if (tamanho_dados <= 0)
            {
                Cabeçalho[1,0] = "24000000";
                Cabeçalho[1,1] = "36 bytes";
                Cab[4] = 0x24; Cab[5] = 0x00; Cab[6] = 0x00; Cab[7] = 0x00;
            }
            else
            {
                Cabeçalho[1, 1] = (36 + tamanho_dados).ToString() + " bytes";
                Cab[4] = (byte)((36 + tamanho_dados) & 0x000000FF);
                Cab[5] = (byte)((36 + tamanho_dados) / 0x100 & 0x000000FF);
                Cab[6] = (byte)((36 + tamanho_dados) / 0x10000 & 0x000000FF);
                Cab[7] = (byte)((36 + tamanho_dados) / 0x1000000 & 0x000000FF);

                StringBuilder sb = new StringBuilder(8);
                sb.AppendFormat("{0:x2}", Cab[4]); //Converte para string hexa
                sb.AppendFormat("{0:x2}", Cab[5]); //Converte para string hexa
                sb.AppendFormat("{0:x2}", Cab[6]); //Converte para string hexa
                sb.AppendFormat("{0:x2}", Cab[7]); //Converte para string hexa
                Cabeçalho[1, 0] = sb.ToString();
            }
            //2 - WAVEfmt (8B)
            Cabeçalho[2, 0] = "57415645666D7420";
            Cabeçalho[2, 1] = "WAVEfmt ";
            Cab[8] = 0x57; Cab[9] = 0x41; Cab[10] = 0x56; Cab[11] = 0x45; Cab[12] = 0x66; Cab[13] = 0x6D; Cab[14] = 0x74; Cab[15] = 0x20;
            //3 - Nulo (4B)
            Cabeçalho[3, 0] = "10000000";
            Cabeçalho[3, 1] = "Campo nulo";
            Cab[16] = 0x10; Cab[17] = 0x00; Cab[18] = 0x00; Cab[19] = 0x00;
            //4 - Estrutura PCM (Pulse Code Modulation - Modulação de Código de Pulso) (2B)
            Cabeçalho[4, 0] = "0100";
            Cabeçalho[4, 1] = "PCM";
            Cab[20] = 0x01; Cab[21] = 0x00;
            //5 - Número de canais (2B)
            switch (eCanais)
            {
                case ClassWAV.Canais.mono: 
                    Cabeçalho[5, 0] = "0100";
                    Cabeçalho[5, 1] = "Mono";
                    Cab[22] = 0x01; Cab[23] = 0x00;
                    iCanais = 1; break; //mono
                case ClassWAV.Canais.estereo:
                    Cabeçalho[5, 0] = "0200";
                    Cabeçalho[5, 1] = "Estéreo";
                    Cab[22] = 0x02; Cab[23] = 0x00;
                    iCanais = 2; break; //estéreo
                default:
                    Cabeçalho[5, 0] = "0000";
                    Cabeçalho[5, 1] = "Nulo";
                    Cab[22] = 0x00; Cab[23] = 0x00;
                    iCanais = 0; break; //nulo
            }
            //6 - Taxa de amostragem (4B)
            switch (eTxAm)
            {
                case ClassWAV.TaxaAm.Tx5000:
                    Cabeçalho[6, 0] = "88130000";
                    Cabeçalho[6, 1] = "5000 Hz";
                    Cab[24] = 0x88; Cab[25] = 0x13; Cab[26] = 0x00; Cab[27] = 0x00;
                    iTxAm = 5000; break; //5000 Hz
                case ClassWAV.TaxaAm.Tx11025:
                    Cabeçalho[6, 0] = "112B0000";
                    Cabeçalho[6, 1] = "11025 Hz";
                    Cab[24] = 0x11; Cab[25] = 0x2B; Cab[26] = 0x00; Cab[27] = 0x00;
                    iTxAm = 11025; break; //11025 Hz
                case ClassWAV.TaxaAm.Tx22050:
                    Cabeçalho[6, 0] = "22560000";
                    Cabeçalho[6, 1] = "22050 Hz";
                    Cab[24] = 0x22; Cab[25] = 0x56; Cab[26] = 0x00; Cab[27] = 0x00;
                    iTxAm = 22050; break; //22050 Hz
                case ClassWAV.TaxaAm.Tx32000:
                    Cabeçalho[6, 0] = "007D0000";
                    Cabeçalho[6, 1] = "32000 Hz";
                    Cab[24] = 0x00; Cab[25] = 0x7D; Cab[26] = 0x00; Cab[27] = 0x00;
                    iTxAm = 44100; break; //32000 Hz
                case ClassWAV.TaxaAm.Tx44100:
                    Cabeçalho[6, 0] = "44AC0000";
                    Cabeçalho[6, 1] = "44100 Hz";
                    Cab[24] = 0x44; Cab[25] = 0xAC; Cab[26] = 0x00; Cab[27] = 0x00;
                    iTxAm = 44100; break; //44100 Hz
                default: 
                    Cabeçalho[6, 0] = "00000000";
                    Cabeçalho[6, 1] = "0 Hz";
                    Cab[24] = 0x00; Cab[25] = 0x00; Cab[26] = 0x00; Cab[27] = 0x00;
                    iTxAm = 0; break;
            }
            //7 - Taxa Média = TxAmostragem * Qminima (depende de outros campos) (4B)

            //8- Quatidade mínima de bytes/amostra = Canais x (Nbits/amostra) / 8 (depende de outros campos) (2B)

            //9 - Número de bits/amostra de cada canal (2B)
            switch (eNbits)
            {
                case ClassWAV.NBits.b8:
                    Cabeçalho[9, 0] = "0800";
                    Cabeçalho[9, 1] = "8 bits";
                    Cab[34] = 0x08; Cab[35] = 0x00;
                    iNbits = 8; break; //8 bits
                case ClassWAV.NBits.b16:
                    Cabeçalho[9, 0] = "1000";
                    Cabeçalho[9, 1] = "16 bits";
                    Cab[34] = 0x10; Cab[35] = 0x00;
                    iNbits = 16; break; //16 bits
                default:
                    Cabeçalho[9, 0] = "0000";
                    Cabeçalho[9, 1] = "0 bits";
                    Cab[34] = 0x00; Cab[35] = 0x00;
                    iNbits = 0; break;
            }
            //10 - Mark = "data" (4B)
            Cabeçalho[10, 0] = "64617461";
            Cabeçalho[10, 1] = "data";
            Cab[36] = 0x64; Cab[37] = 0x61; Cab[38] = 0x74; Cab[39] = 0x61;
            //11 - SizeData (4B)
            Cabeçalho[11, 1] = tamanho_dados.ToString() + " bytes";
            Cab[40] = (byte)(tamanho_dados & 0x000000FF);
            Cab[41] = (byte)(tamanho_dados / 0x100 & 0x000000FF);
            Cab[42] = (byte)(tamanho_dados / 0x10000 & 0x000000FF);
            Cab[43] = (byte)(tamanho_dados / 0x1000000 & 0x000000FF);
            
            StringBuilder sb2 = new StringBuilder(8);
            sb2.AppendFormat("{0:x2}", Cab[40]); //Converte para string hexa
            sb2.AppendFormat("{0:x2}", Cab[41]); //Converte para string hexa
            sb2.AppendFormat("{0:x2}", Cab[42]); //Converte para string hexa
            sb2.AppendFormat("{0:x2}", Cab[43]); //Converte para string hexa
            Cabeçalho[11, 0] = sb2.ToString();
            //8- Quatidade mínima de bytes/amostra = Canais x (Nbits/amostra) / 8 (depende de outros campos) (2B)
            iQmin = iCanais * iNbits / 8;
            switch (iQmin)
            {
                case 1:
                    Cabeçalho[8, 0] = "0100";
                    Cabeçalho[8, 1] = "1 byte/amostra";
                    Cab[32] = 0x01; Cab[33] = 0x00;
                    break; //8 bits mono
                case 2:
                    Cabeçalho[8, 0] = "0200";
                    Cabeçalho[8, 1] = "2 bytes/amostra";
                    Cab[32] = 0x02; Cab[33] = 0x00;
                    break; //8 bits estéreo ou 16 bits mono
                case 4:
                    Cabeçalho[8, 0] = "0400";
                    Cabeçalho[8, 1] = "4 bytes/amostra";
                    Cab[32] = 0x04; Cab[33] = 0x00;
                    break; //16 bits estéreo
                default:
                    Cabeçalho[8, 0] = "0000";
                    Cabeçalho[8, 1] = "0 bytes/amostra";
                    Cab[32] = 0x00; Cab[33] = 0x00;
                    break;
            }            
            //7 - Taxa Média = TxAmostragem * Qminima (depende de outros campos) (4B)
            iTmed = iTxAm * iQmin;
            Cabeçalho[7, 1] = iTmed.ToString() + " bytes/s";
            Cab[28] = (byte)(iTmed & 0x000000FF);
            Cab[29] = (byte)(iTmed / 0x100 & 0x000000FF);
            Cab[30] = (byte)(iTmed / 0x10000 & 0x000000FF);
            Cab[31] = (byte)(iTmed / 0x1000000 & 0x000000FF);

            StringBuilder sb3 = new StringBuilder(8);
            sb3.AppendFormat("{0:x2}", Cab[28]); //Converte para string hexa
            sb3.AppendFormat("{0:x2}", Cab[29]); //Converte para string hexa
            sb3.AppendFormat("{0:x2}", Cab[30]); //Converte para string hexa
            sb3.AppendFormat("{0:x2}", Cab[31]); //Converte para string hexa
            Cabeçalho[7, 0] = sb3.ToString();
            
            //Retorna matriz de strings com configurações
            campos = Cabeçalho;
            //Retorna a matriz de bytes
            return Cab;
        }
        /// <summary>
        /// Monta dados (amostragens) de arquivo WAVE
        /// </summary>
        /// <param name="onda">Forma de onde a ser criada</param>
        /// <param name="freq">Frequência</param>
        /// <param name="ciclos">Número de ciclos (repetições)</param>
        /// <param name="amplitude">Amplitude do sinal (0 a 100%)</param>
        /// <param name="bitmap">Bitmap para desenho da onda</param>
        /// <param name="info">Matriz de strings atualizada com:
        /// Tamanho em bytes,
        /// Pontos/ciclo,
        /// Tempo em segundos,
        /// Dado de um ciclo em string HEXA</param>
        /// <returns>Vetor de bytes com todas as amostragens</returns>
        public byte[] montaDadosArquivo(Onda onda, int freq, int ciclos, int amplitude, Bitmap bitmap, out string[,] info)
        {
            byte[] Dados = new byte[0];
            string[,] Info = new string[4,2];

            Info[0, 0] = "Tamanho (B)";
            Info[1, 0] = "Pontos/ciclo";
            Info[2, 0] = "Tempo (s)";
            Info[3, 0] = "Dado de um ciclo";

            int pontosPeriodo;
            int SizeCiclo;            
            int SizeData;
            if (freq < 1) freq = 1;
            if (ciclos < 1) ciclos = 1;
            if (amplitude < 0) amplitude = 0;
            if (amplitude > 100) amplitude = 100;

            try
            {
                //Repetir forma de onda de acordo com a quantidade de ciclos
                pontosPeriodo = iTxAm / freq;                                           //Cálculo de pontos por período
                Info[1, 1] = pontosPeriodo.ToString();                                  //Pontos
                Info[2, 1] = Math.Round(((double)1 / freq * ciclos), 3).ToString();     //Tempo = período * ciclos
                int[] ponto = new int[pontosPeriodo];                                   //Cria vetor de pontos

                //Criação de forma de onda com essa quantidade de pontos com resolução de 8 ou 16 bits
                switch (onda)
                {
                    case Onda.Senóide: //Cria senoide
                        for (int i = 0; i < pontosPeriodo; i++)
                        {
                            //step = 2pi/pontosPeriodo
                            //sen(step*i) = -1 a 1
                            //desejo que quando sen é 0 a saída seja a metade da amplitude (2^Nbits/2) = 128 (para 8 bits)
                            //o sen é multiplicado por 2^Nbits/2 - 1 = -127 a 127 (para 8 bits)
                            ponto[i] = (int)(Math.Sin((2 * Math.PI / pontosPeriodo) * i) * (Math.Pow(2, iNbits) / 2 - 1) + Math.Pow(2, iNbits) / 2);
                        }
                        break;
                    case Onda.DenteSerra: //Cria dente de serra
                        for (int i = 0; i < pontosPeriodo; i++)
                        {
                            ponto[i] = (int)((Math.Pow(2, iNbits) - 1) / pontosPeriodo * i);
                        }
                        break;
                    case Onda.Triangular: //Cria onda triangular
                        for (int i = 0; i < pontosPeriodo; i++)
                        {
                            if (i < pontosPeriodo / 2)
                                ponto[i] = (int)((Math.Pow(2, iNbits) - 1) / (pontosPeriodo / 2) * i);
                            else
                                //Valor Máximo            - Valor Máximo             / (pontos/2)          * (i-(pontos/2)) 
                                ponto[i] = (int)((Math.Pow(2, iNbits) - 1) - (Math.Pow(2, iNbits) - 1) / (pontosPeriodo / 2) * (i - (pontosPeriodo / 2)));
                        }
                        break;
                    case Onda.Quadrada: //Cria onda quadrada
                        for (int i = 0; i < pontosPeriodo; i++)
                        {
                            if (i < pontosPeriodo / 2)
                                ponto[i] = (int)(Math.Pow(2, iNbits) - 1);
                            else
                                ponto[i] = 0;
                        }
                        break;
                    case Onda.Customizada: //Cria onda customizada
                        //Define o step X
                        double stepX = (double)bitmap.Width / pontosPeriodo;

                        for (int i = 0; i < pontosPeriodo; i++)
                        {
                            int x = (int)(stepX * i);
                            int y = 0;
                            double y_percentual = 0;

                            //Ler de cima para baixo
                            //Enquanto o pixel da coluna x não é azul e não chegou no último pixel
                            while ((bitmap.GetPixel(x, y).B != 255) && (y < (bitmap.Height - 1))) { y++; }
                            //Grava o ponto do pixel que tem vermelho saturado
                            y_percentual = (double)((bitmap.Height - 1) - y) / (bitmap.Height - 1);
                            //Normalizar os pontos
                            ponto[i] = (int)(y_percentual * (Math.Pow(2, iNbits) - 1));
                        }
                        break;
                }
                //Ajuste de escala (0 a 100%)
                for (int i = 0; i < pontosPeriodo; i++)
                {
                    ponto[i] = (ponto[i] * amplitude) / 100;
                }
                //Desenho dos pontos no PictureBox
                Graphics desenhador;
                //desenhador = pbOnda.CreateGraphics();
                desenhador = Graphics.FromImage(bitmap);
                Brush pincel = new SolidBrush(Color.Yellow);
                double step = (double)bitmap.Width / pontosPeriodo;
                for (int i = 0; i < pontosPeriodo; i++)
                {
                    int x = (int)(step * i);
                    int y = (int)(bitmap.Height - 2 - (double)(bitmap.Height - 2) / (Math.Pow(2, iNbits) - 1) * ponto[i]); //-2 ajuste fino
                    desenhador.FillEllipse(pincel, x, y, 2, 2);
                }
                //Mongem da string com cada um dos pontos representados em hexa
                StringBuilder sb = new StringBuilder(pontosPeriodo * 2);
                //4 opções de montagem
                //1a Opção - Mono 8 bits
                if (iCanais == 1 && iNbits == 8)
                {
                    sb = new StringBuilder(pontosPeriodo * 2);
                    foreach (int p in ponto)
                    {
                        sb.AppendFormat("{0:x2}", p);  //Mostra em hexa
                    }
                }
                //2a Opção - Mono 16 bits
                if (iCanais == 1 && iNbits == 16)
                {
                    sb = new StringBuilder(pontosPeriodo * 4);
                    foreach (int p in ponto)
                    {   //Verificar a ordem
                        sb.AppendFormat("{0:x2}", p % 255);  //Mostra o LSB em hexa
                        sb.AppendFormat("{0:x2}", p / 255);  //Mostra o MSB em hexa
                    }
                }
                //3a Opção - Estéreo 8 bits
                if (iCanais == 2 && iNbits == 8)
                {
                    sb = new StringBuilder(pontosPeriodo * 4);
                    foreach (int p in ponto)
                    {
                        sb.AppendFormat("{0:x2}", p);  //Mostra em hexa o canal direito
                        sb.AppendFormat("{0:x2}", p);  //Mostra em hexa o canal esquerdo
                    }
                }
                //4a Opção - Estéreo 16 bits
                if (iCanais == 2 && iNbits == 16)
                {
                    sb = new StringBuilder(pontosPeriodo * 8);
                    foreach (int p in ponto)
                    {
                        sb.AppendFormat("{0:x2}", p % 255);  //Mostra o LSB do canal direito em hexa
                        sb.AppendFormat("{0:x2}", p / 255);  //Mostra o MSB do canal direito em hexa
                        sb.AppendFormat("{0:x2}", p % 255);  //Mostra o LSB do canal esquerdo em hexa
                        sb.AppendFormat("{0:x2}", p / 255);  //Mostra o MSB do canal esquerdo em hexa
                    }
                }
                //Apresenta um ciclo completo na string Info
                Info[3, 1] = sb.ToString();
                //Calcular a quantidade de bytes e tamanho do arquivo - 8 bytes
                SizeCiclo = sb.Length / 2;          //Tamanho do sb / (2 caracteres po byte)
                SizeData = SizeCiclo * ciclos;
                iTamDados = SizeData;
                Info[0, 1] = SizeData.ToString();   //Tamanho (B)
                Dados = new byte[SizeData]; //Define o tamanho dos dados
                //Monta um vetor com todos os dados de um ciclo
                for (int i = 0; i < SizeCiclo; i++)
                {
                    Dados[i] = Convert.ToByte(Info[3, 1].Substring(i * 2, 2), 16);
                }
                //Repete Dados pela quantidade de ciclos
                for (int i = 1; i < ciclos; i++)
                {
                    for (int j = 0; j < SizeCiclo; j++)
                    {
                        Dados[SizeCiclo * i + j] = Dados[j];
                    }                    
                }
            }
            catch (Exception) { }

            //Retorna informações
            info = Info;
            //Retorna vetor de bytes
            return Dados;
        }
        /// <summary>
        /// Monta uma arquivo WAVE com formatação pré-definida 
        /// (canal = mono, taxa = 22050 Hz, bits/amostra = 8 bits, tempo = 2 segundos) 
        /// </summary>
        /// <param name="onda">Forma de onde a ser criada</param>
        /// <param name="freq">Frequência</param>
        /// <param name="bitmap">Bitmap para desenho da onda</param>
        /// <returns></returns>
        public byte[] montaFacil(Onda onda, int freq, Bitmap bitmap)
        {
            string[,] Info, Campos;
            byte[] Dados, Cabeçalho, Full;
            int tempo = 2;
            int ciclos = tempo * freq;                 //ciclos = tempo / período = tempo * freq
            int escala = 100;
            
            Dados = montaDadosArquivo(onda, freq, ciclos, escala, bitmap, out Info);
            Cabeçalho = montaCabArquivo(Canais.mono, TaxaAm.Tx22050, NBits.b8, Dados.Length, out Campos);

            //Concatena os dois vetores
            Full = new byte[Dados.Length + Cabeçalho.Length];

            int b = 0;
            for (int i = 0; i < Cabeçalho.Length; i++)
            {
                Full[b++] = Cabeçalho[i]; 
            }
            for (int i = 0; i < Dados.Length; i++)
            {
                Full[b++] = Dados[i];
            }

            //Retorno
            return Full;
        }
    }
}
