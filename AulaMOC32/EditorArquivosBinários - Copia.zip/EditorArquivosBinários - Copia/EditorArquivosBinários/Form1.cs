﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;              //Incluido manualmente
using System.Media;           //Para usar a classe SoundPlayer
using System.Threading;

namespace EditorArquivosBinários
{
    public partial class Form1 : Form
    {
        string arquivoAberto = "";

        public Form1()
        {
            InitializeComponent();
            //Instancia o bitmap bm
            bm = new Bitmap(pbOnda.Width, pbOnda.Height);
            //Instancia o Graphics desenhador_cust
            desenhador_cust = Graphics.FromImage(bm);
        }

        #region Arquivo (abrir, salvar)
        /// <summary>
        /// Abre arquivo WAVE e lê todo o cabeçalho e 200 primeiros bytes de dados
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void abrirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Cria dinamicamente uma caixa de arquivo
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.InitialDirectory = "Sons\\";  //Define o diretório inicial
            openFileDialog1.Filter = "text files (*.txt)|*.txt|bmp files (*.bmp)|*.bmp|wave files (*.wav)|*.wav|All files (*.*)|*.*"; //Define os filtros
            openFileDialog1.FilterIndex = 1;    //Seleciona o filtro inicial
            openFileDialog1.RestoreDirectory = true;   //Restaura o diretório atual ao fechar

            //Se clicou em OK após selecionar um arquivo
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //Teste arquivo binário
                StringBuilder sb = new StringBuilder(200);
                StringBuilder sb2 = new StringBuilder(200);

                try
                {
                    byte[] arquivo = File.ReadAllBytes(openFileDialog1.FileName);  //Lê todos os bytes do arquivo
                    tbTamanho.Text = arquivo.Length.ToString();             //Exibe o tamanho do arquivo
                    MessageBox.Show("Arquivo aberto com sucesso");
                    arquivoAberto = openFileDialog1.FileName;
                    tbAberto.Text = arquivoAberto;

                    //Se for arquivo de texto (TXT)
                    if (openFileDialog1.FilterIndex == 1)
                    {
                        this.Text = "Arquivo de TEXTO (" + arquivoAberto + ")";

                        ClassTXT txt = new ClassTXT(arquivoAberto);         //Instanciamento do classe ClassTXT

                        txt.leASCII(tbASCII);                               //Lê arquivo em ASCII
                        int l = txt.leHEXA(tbHEXA);                         //Lê arquivo em HEXA e retorna quantidade de bytes
                        tbHEXAQTB.Text = l.ToString();
                        txt.leASCII_sem_formatação(tbMIXASCII, 0, 100);     //Lê parte do arquivo em ASCII
                        l = txt.leHEXA_sem_formatação(tbMIXHEXA, 0, 100);   //Lê parte do arquivo em HEXA e retorna quantidade de bytes do arquivo
                        tbMIXQTB.Text = l.ToString();
                    }
                    //Se for arquivo de imagem bitmap (BMP)
                    if (openFileDialog1.FilterIndex == 2)
                    {
                        this.Text = "Arquivo de IMAGEM (" + arquivoAberto + ")";

                        ClassBMP bmp = new ClassBMP(arquivoAberto);         //Instanciamento do classe ClassBMP

                        bmp.leCabArquivo(dgCab1);                           //Lê o cabeçalho do arquivo
                        tbCab1.Text = "14";
                        bmp.leCabMapaDeBits(dgCab2);                        //Lê o cabeçalho do mapa de bits do arquivo
                        tbCab2.Text = "40";
                        bmp.lePaletaDeCores(dgPaleta);                      //Lê a paleta de cores do arquivo
                        tbPaleta.Text = "4 x núm. cores";

                        int l = bmp.leHEXA(tbBMP);                          //Lê arquivo em HEXA e retorna quantidade de bytes
                        tbBMPQTB.Text = l.ToString();
                        pbBMP.ImageLocation = openFileDialog1.FileName;     //Abre a imagem selecionada no PictureBox
                    }
                    //Se for arquivo de audio wave (WAV)
                    else if (openFileDialog1.FilterIndex == 3)
                    {
                        this.Text = "Teste de Arquivos WAVE (" + arquivoAberto + ")";

                        ClassWAV wav = new ClassWAV(arquivoAberto);         //Instancimento do classe ClassWAV

                        wav.leHEXA_sem_formatação(tbCabeçalho, 0, 44);      //Lê parte do arquivo em HEXA e retorna quantidade de bytes do arquivo
                        wav.leCabArquivo(dgCabeçalho);

                        int l = wav.leHEXA_sem_formatação(tbDados, 44, 200);//Lê parte do arquivo em HEXA e retorna quantidade de bytes do arquivo
                        tbQTB.Text = l.ToString();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Erro ao tentar acessar o arquivo");
                }
            }
        }
        /// <summary>
        /// Salva o arquivo WAVE montado com o nome do arquivo aberto
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void salvarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int ciclos = int.Parse(tbCiclos.Text);
            byte[] arquivo2 = new byte[tbMontaCabeçalho.TextLength / 2 + (tbMontaDados.TextLength / 2) * ciclos];  //Cabeçalho + Dados

            //Se existe uma arquivo aberto sobreescreve com o arquivo montado
            if (File.Exists(arquivoAberto))
            {
                try
                {
                    int i;
                    for (i = 0; i < tbMontaCabeçalho.TextLength / 2; i++)
                    {
                        string hex = tbMontaCabeçalho.Text.Substring(i * 2, 2);
                        //(string,base)
                        arquivo2[i] = Convert.ToByte(hex, 16);
                    }

                    for (int c = 0; c < ciclos; c++)    //Repete esta tarefa de acordo com a quantidade de ciclos escolhida
                    {
                        for (int j = 0; j < tbMontaDados.TextLength / 2; j++)
                        {
                            string hex = tbMontaDados.Text.Substring(j * 2, 2);
                            //(string,base)
                            arquivo2[i++] = Convert.ToByte(hex, 16);
                        }
                    }
                    //Cria ou abre um arquivo
                    File.WriteAllBytes(arquivoAberto, arquivo2);

                    MessageBox.Show("Arquivo salvo com sucesso");
                    //this.Text = "Teste de Arquivos WAVE (" + arquivoAberto + ")";
                    //tbAberto.Text = arquivoAberto;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Erro ao salvar o arquivo");
                    arquivoAberto = "";
                }
            }
        }
        /// <summary>
        /// Salva o arquivo WAVE montado com o nome desejado
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void salvarComoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int ciclos = int.Parse(tbCiclos.Text);
            byte[] arquivo2 = new byte[tbMontaCabeçalho.TextLength / 2 + (tbMontaDados.TextLength / 2) * ciclos];  //Cabeçalho + Dados

            //Cria dinamicamente uma caixa de arquivo
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.InitialDirectory = "Sons\\";  //Define o diretório inicial
            saveFileDialog1.Filter = "wave files (*.wav)|*.wav|All files (*.*)|*.*"; //Define os filtros
            saveFileDialog1.FilterIndex = 1;    //Seleciona o filtro inicial
            saveFileDialog1.RestoreDirectory = true;   //Restaura o diretório atual ao fechar

            //Se clicou em OK após selecionar um arquivo
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    int i;
                    for (i = 0; i < tbMontaCabeçalho.TextLength / 2; i++)
                    {
                        string hex = tbMontaCabeçalho.Text.Substring(i * 2, 2);
                        //(string,base)
                        arquivo2[i] = Convert.ToByte(hex, 16);
                    }

                    for (int c = 0; c < ciclos; c++)    //Repete esta tarefa de acordo com a quantidade de ciclos escolhida
                    {
                        for (int j = 0; j < tbMontaDados.TextLength / 2; j++)
                        {
                            string hex = tbMontaDados.Text.Substring(j * 2, 2);
                            //(string,base)
                            arquivo2[i++] = Convert.ToByte(hex, 16);
                        }
                    }
                    //Cria ou abre um arquivo
                    File.WriteAllBytes(saveFileDialog1.FileName, arquivo2);

                    MessageBox.Show("Arquivo salvo com sucesso");
                    arquivoAberto = saveFileDialog1.FileName;
                    this.Text = "Teste de Arquivos WAVE (" + arquivoAberto + ")";
                    tbAberto.Text = arquivoAberto;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Erro ao salvar o arquivo");
                    arquivoAberto = "";
                }
            }
        }
        #endregion

        #region Arquivo WAVE (manipulação)

        SoundPlayer player = new SoundPlayer(); //Intancia a classe reprodutora de arquivos WAV

        /// <summary>
        /// Reproduz o arquivo WAVE aberto
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bPlay_Click(object sender, EventArgs e)
        {
            try
            {
                player.SoundLocation = tbAberto.Text;
                player.Play();
            }
            catch (Exception erro)
            {
                MessageBox.Show(erro.Message, "ERRO");
            }
        }
        /// <summary>
        /// Abre arquivo WAVE e lê todo o cabeçalho e 200 primeiros bytes de dados
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bLer_Click(object sender, EventArgs e)
        {
            #region Modelo do arquivo WAVE
            /*
            O Arquivo WAVE
            Wave :: Cabeçalho Dados
            
            Cabeçalho :: RIFF Tamanho WAVEfmt Estrutura Canais TxAmostragem Tmedia Qminima Nbits Mark SizeData
            RIFF :: 4 BYTES (0 - 3). Código Hexadecimal da string "RIFF" (52 49 46 46)
            Tamanho :: 4 BYTES (4 - 7). Tamanho total do arquivo
            WAVEfmt :: 8 BYTES (8 - 15). Código Hexadecimal da string "WAVEfmt" (57 41 56 45 66 6D 74 20)
            Estrutura :: 2 BYTES (20-21) - Tipo de Estrutura. PCM (Pulse Code Modulation - Modulação de Código de Pulso)
            Canais :: 2 Bytes (22 – 23). Quantidade de Canais.
                                        01: Monofônico
                                        02: Estéreofônico
            TxAmostragem :: 4 Bytes (24 – 27). Taxa de Amostragem para PCM: 5000Hz, 11025Hz, 22050Hz, 44100Hz.
                                        Comercialmente as principais taxas de amostragem são as seguintes:
                                        ¨ 11.025 Hz: padrão geralmente utilizado para qualidade de telefone;
                                        ¨ 22.050 Hz: padrão geralmente utilizado para qualidade de rádio;
                                        ¨ 44.100 Hz: padrão geralmente utilizado para qualidade de CD.
                                        ¨ 32.000 Hz: proporciona bons resultados para fins auditivos,
                                                    com quantidade superior ao padrão de rádio e telefone e,
                                                    inferior ao de CD.
            Tmedia :: 4 Bytes (28 – 31). Taxa Média de Transferência.
            Qminima :: 2 Bytes (32 – 33). Quantidade mínima de bytes utilizados para representar uma amostra. 
                                      Para PCM: é o número de bytes utilizados para representar uma amostra 
                                      simples, incluindo os dados para ambos canais, caso seja no formato estéreo.
                                        8 bits mono: 01,
                                        8 bits estéreo: 02.
                                        16 bits mono: 02,
                                        16 bits estéreo: 04.
            Nbits :: 2 Bytes (34 – 35). Número de bits por amostra.
                                        08: oito bists
                                        16: dezesseis bits
            Mark :: 4 Bytes (36 – 39). Código Hexadecimal da string “data” (64 61 74 61).
            SizeData :: 4 Bytes (40 – 43). Número de bytes de dados a serem lidos.
            
            Dados :: Bytes
            */
            #endregion

            try
            {
                ClassWAV wav = new ClassWAV(arquivoAberto);         //Instancimento do classe ClassWAV

                wav.leHEXA_sem_formatação(tbCabeçalho, 0, 44);      //Lê parte do arquivo em HEXA e retorna quantidade de bytes do arquivo
                wav.leCabArquivo(dgCabeçalho);

                int l = wav.leHEXA_sem_formatação(tbDados, 44, 200);//Lê parte do arquivo em HEXA e retorna quantidade de bytes do arquivo
                tbQTB.Text = l.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro ao tentar acessar o arquivo");
            }

        }
        /// <summary>
        /// Lê a quantidade que dados especificado do arquivo WAVE aberto
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bDados_Click(object sender, EventArgs e)
        {
            int tamanho = 0;
            int posição = 0;

            try
            {
                tamanho = int.Parse(tbBytes.Text);
                posição = int.Parse(tbInicio.Text);
                StringBuilder sb = new StringBuilder(tamanho);

                //Instancimaneto do classe ClassWAV
                ClassWAV wav = new ClassWAV(arquivoAberto);
                int l = wav.leHEXA_sem_formatação(tbDados, posição, tamanho);   //Lê parte do arquivo em HEXA e retorna quantidade de bytes do arquivo
                tbQTB.Text = l.ToString();
                //Evita erro ao ler o arquivo
                if (posição >= l)
                {
                    posição = l - 1;    //Define como a últim posição do arquivo
                    tbInicio.Text = posição.ToString();
                    tamanho = 1;        //Lê apenas um byte
                    tbBytes.Text = tamanho.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro ao tentar acessar o arquivo");
            }
        }
        /// <summary>
        /// Lê o próximo conjunto de dados de acorco com a quantidade especificada do arquivo WAVE aberto
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bProx_Click(object sender, EventArgs e)
        {
            int posição = 0;
            posição = int.Parse(tbInicio.Text) + int.Parse(tbBytes.Text);   //Soma a posição atual a quantidade de bytes a serm lidos 
            tbInicio.Text = posição.ToString();     //Atualiza a o TexbBox com a nova posição de início
            bDados.PerformClick();                  //Dispara o método de leitora de dados
        }
        #endregion

        #region Arquivo WAVE (criação)
        /// <summary>
        /// Variáveis comuns a montagem de um arquivo WAVE
        /// </summary>
        int Canais = 0;
        int TxAm = 0;
        int Qmin = 0;
        int Tmed = 0;
        int Nbits = 0;
        int Tamanho = 36;
        int SizeData = 0;
        /// <summary>
        /// Monta o cabeçalho de um arquivo WAVE baseado na seleção feita
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bMontaCab_Click(object sender, EventArgs e)
        {
            //Cria enumerações de formatação de arquivo WAVE
            ClassWAV.Canais canais;
            ClassWAV.TaxaAm txAm;
            ClassWAV.NBits nBits;

            //5 - Número de canais (2B)
            switch (cbCanais.SelectedIndex)
            {
                case 0: Canais = 1; canais = ClassWAV.Canais.mono; break; //mono
                case 1: Canais = 2; canais = ClassWAV.Canais.estereo; break; //estéreo
                default: Canais = 0; canais = 0; break;
            }
            //6 - Taxa de amostragem (4B)
            switch (cbTxAm.SelectedIndex)
            {
                case 0: TxAm = 5000; txAm = ClassWAV.TaxaAm.Tx5000; break; //5000 Hz
                case 1: TxAm = 11025; txAm = ClassWAV.TaxaAm.Tx11025; break; //11025 Hz
                case 2: TxAm = 22050; txAm = ClassWAV.TaxaAm.Tx22050; break; //22050 Hz
                case 3: TxAm = 32000; txAm = ClassWAV.TaxaAm.Tx32000; break; //32000 Hz
                case 4: TxAm = 44100; txAm = ClassWAV.TaxaAm.Tx44100; break; //44100 Hz
                default: TxAm = 0; txAm = 0; break;
            }
            //9 - Número de bits/amostra de cada canal (2B)
            switch (cbNbits.SelectedIndex)
            {
                case 0: Nbits = 8; nBits = ClassWAV.NBits.b8; break; //8 bits
                case 1: Nbits = 16; nBits = ClassWAV.NBits.b16; break; //16 bits
                default: Nbits = 0; nBits = 0; break;
            }
            //11 - SizeData (4B)
            try { SizeData = int.Parse(tbSizeDataDecimal.Text); }
            catch { SizeData = 0; };

            string[,] configurado;
            //Instancia a classe ClassWAV para criação da arquivo WAVE
            ClassWAV wav = new ClassWAV(canais, txAm, nBits);
            //Cria cabeçalho de arquivo WAVE
            byte[] cabeçalho = wav.montaCabArquivo(SizeData, out configurado);

            tbTam.Text = configurado[1, 0];
            lTamanho.Text = "= " + configurado[1, 1];
            tbCanais.Text = configurado[5, 0];
            tbTxAm.Text = configurado[6, 0];
            tbTmedia.Text = configurado[7, 0];
            lTmedia.Text = "= " + configurado[7, 1];
            tbQminima.Text = configurado[8, 0];
            lQminima.Text = "= " + configurado[8, 1];
            tbNbits.Text = configurado[9, 0];
            tbSizeData.Text = configurado[11, 0];

            //Transforma os bytes no cabeçalho em string hexa
            StringBuilder sb = new StringBuilder(cabeçalho.Length * 2);
            foreach (byte x in cabeçalho)
            {
                sb.AppendFormat("{0:x2}", x);
            }
            tbMontaCabeçalho.Text = sb.ToString();
        }
        /// <summary>
        /// Atualiza campos que remetem ao cabeçalho do arquivo WAVE
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bAtualizar_Click(object sender, EventArgs e)
        {
            tbCanais2.Text = Canais.ToString();
            tbTxAm2.Text = TxAm.ToString();
            tbQminima2.Text = Qmin.ToString();
            tbTmedia2.Text = Tmed.ToString();
            tbNbits2.Text = Nbits.ToString();
        }
        /// <summary>
        /// Define a amplitude da forma de onda criada
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void trackBarAmplitude_Scroll(object sender, EventArgs e)
        {
            lAmplitude.Text = trackBarAmplitude.Value.ToString();
        }
        /// <summary>
        /// Monta os dados de um arquivo WAVE baseado na seleção feita
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bMontarDados_Click(object sender, EventArgs e)
        {
            int freq, ciclos, escala;
            string[,] informações = new string[4, 2];
            ClassWAV.Canais canais;
            ClassWAV.TaxaAm txAm;
            ClassWAV.NBits nBits;
            ClassWAV.Onda onda;

            try
            {
                //Repetir forma de onda de acordo com a quantidade de ciclos
                ciclos = int.Parse(tbCiclos.Text);
                //Lê a frequência do sinal desejado
                freq = int.Parse(tbFreq.Text);
                //Lê a escala de amplitude a ser utilizada
                escala = (trackBarAmplitude.Value) % 101;

                //5 - Número de canais (2B)
                switch (cbCanais.SelectedIndex)
                {
                    case 0: Canais = 1; canais = ClassWAV.Canais.mono; break; //mono
                    case 1: Canais = 2; canais = ClassWAV.Canais.estereo; break; //estéreo
                    default: Canais = 0; canais = 0; break;
                }
                //6 - Taxa de amostragem (4B)
                switch (cbTxAm.SelectedIndex)
                {
                    case 0: TxAm = 5000; txAm = ClassWAV.TaxaAm.Tx5000; break; //5000 Hz
                    case 1: TxAm = 11025; txAm = ClassWAV.TaxaAm.Tx11025; break; //11025 Hz
                    case 2: TxAm = 22050; txAm = ClassWAV.TaxaAm.Tx22050; break; //22050 Hz
                    case 3: TxAm = 32000; txAm = ClassWAV.TaxaAm.Tx32000; break; //32000 Hz
                    case 4: TxAm = 44100; txAm = ClassWAV.TaxaAm.Tx44100; break; //44100 Hz
                    default: TxAm = 0; txAm = 0; break;
                }
                //9 - Número de bits/amostra de cada canal (2B)
                switch (cbNbits.SelectedIndex)
                {
                    case 0: Nbits = 8; nBits = ClassWAV.NBits.b8; break; //8 bits
                    case 1: Nbits = 16; nBits = ClassWAV.NBits.b16; break; //16 bits
                    default: Nbits = 0; nBits = 0; break;
                }
                //Forma de onda
                switch (cbFormaDeOnda.SelectedIndex)
                {
                    case 0: onda = ClassWAV.Onda.Senóide; break;
                    case 1: onda = ClassWAV.Onda.DenteSerra; break;
                    case 2: onda = ClassWAV.Onda.Triangular; break;
                    case 3: onda = ClassWAV.Onda.Quadrada; break;
                    case 4: onda = ClassWAV.Onda.Customizada; break;
                    default: onda = 0; break;
                }

                ClassWAV wav = new ClassWAV(canais, txAm, nBits);
                byte[] dados = wav.montaDadosArquivo(onda, freq, ciclos, escala, bm, out informações);

                tbTotalBytes.Text = informações[0, 1];
                tbSizeDataDecimal.Text = informações[0, 1];  //Tela de cabeçalho
                tbPontos.Text = informações[1, 1];
                tbTempo.Text = informações[2, 1];
                tbMontaDados.Text = informações[3, 1];
                //Atualiza o PictureBox
                pbOnda.Image = bm;
            }
            catch
            { }
        }
        /// <summary>
        /// Monta cabeçalho e dados com formatação padrão
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bMontarFull_Click(object sender, EventArgs e)
        {
            ClassWAV wav = new ClassWAV();
            byte[] dados = wav.montaFacil(ClassWAV.Onda.Senóide, 100, bm);
            //Atualiza o PictureBox
            pbOnda.Image = bm;
            //Converte bytes para string HEXA
            StringBuilder sb = new StringBuilder(dados.Length * 2);
            foreach (byte b in dados)
            {
                sb.AppendFormat("{0:x2}", b);
            }
            //Atualixa a caixa de texto
            tbMontaDados.Text = sb.ToString();
        }
        #endregion

        #region Arquivo WAVE (customização de onda)
        /// <summary>
        /// Variáveis comuns para customização de onda
        /// </summary>
        bool press = false;
        int xini, yini;
        Pen caneta = new Pen(Color.Blue, 2);
        Bitmap bm;  //Inicialização no método construtor
        //Desenho dos pontos no PictureBox
        Graphics desenhador_cust;
        /// <summary>
        /// Verifica quando o mouse é pressionado sobre o PictureBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pbOnda_MouseDown(object sender, MouseEventArgs e)
        {
            if (cbFormaDeOnda.SelectedIndex == 4)   //Se selecionou customizado
            {
                press = true;
                //Lê as coordenadas iniciais
                xini = e.X;
                yini = e.Y;

            }
            else
            {
                press = false;
            }
        }
        /// <summary>
        /// Verifica quando o mouse é solto sobre o PictureBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pbOnda_MouseUp(object sender, MouseEventArgs e)
        {
            press = false;
        }
        /// <summary>
        /// Desenha sobre o PictureBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pbOnda_MouseMove(object sender, MouseEventArgs e)
        {
            int x, y;
            if (press)
            {
                x = e.X;
                y = e.Y;
                //Cria uma área de ação para o desenhador
                //desenhador_cust = pbOnda.CreateGraphics();
                desenhador_cust = Graphics.FromImage(bm);
                //Desenha uma reta entre os pontos anterior a atual
                desenhador_cust.DrawLine(caneta, xini, yini, x, y);
                //Atualiza os pontos anteriores
                xini = x;
                yini = y;
                //Atualiza o PictureBox
                pbOnda.Image = bm;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bClear_Click(object sender, EventArgs e)
        {
            if (desenhador_cust != null)
            {
                desenhador_cust.Clear(Color.Black);
                pbOnda.Image = bm;
            }
        }
        #endregion

        #region Arquivo TXT (manipulação)
        private void bLerHEXA_Click(object sender, EventArgs e)
        {
            int tamanho = 0;
            int posição = 0;

            try
            {
                tamanho = int.Parse(tbHEXABytes.Text);
                posição = int.Parse(tbHEXAInicio.Text);
                StringBuilder sb = new StringBuilder(tamanho);

                //Instancimaneto do classe ClassTXT
                ClassTXT txt = new ClassTXT(arquivoAberto);
                int l = txt.leHEXA_sem_formatação(tbHEXA, posição, tamanho);   //Lê parte do arquivo em HEXA e retorna quantidade de bytes do arquivo
                tbHEXAQTB.Text = l.ToString();
                //Evita erro ao ler o arquivo
                if (posição >= l)
                {
                    posição = l - 1;    //Define como a últim posição do arquivo
                    tbHEXAInicio.Text = posição.ToString();
                    tamanho = 1;        //Lê apenas um byte
                    tbHEXABytes.Text = tamanho.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro ao tentar acessar o arquivo");
            }
        }

        private void bHEXAProx_Click(object sender, EventArgs e)
        {
            int posição = 0;
            posição = int.Parse(tbHEXAInicio.Text) + int.Parse(tbHEXABytes.Text);   //Soma a posição atual a quantidade de bytes a serm lidos 
            tbHEXAInicio.Text = posição.ToString();     //Atualiza a o TexbBox com a nova posição de início
            bHEXALer.PerformClick();                      //Dispara o método de leitora de dados
        }

        private void bMIXDados_Click(object sender, EventArgs e)
        {
            int tamanho = 0;
            int posição = 0;

            try
            {
                tamanho = int.Parse(tbMIXBytes.Text);
                posição = int.Parse(tbMIXInicio.Text);
                StringBuilder sb = new StringBuilder(tamanho);

                //Instancimaneto do classe ClassTXT
                ClassTXT txt = new ClassTXT(arquivoAberto);
                txt.leASCII_sem_formatação(tbMIXASCII, posição, tamanho);
                int l = txt.leHEXA_sem_formatação(tbMIXHEXA, posição, tamanho);   //Lê parte do arquivo em HEXA e retorna quantidade de bytes do arquivo
                tbHEXAQTB.Text = l.ToString();
                //Evita erro ao ler o arquivo
                if (posição >= l)
                {
                    posição = l - 1;    //Define como a últim posição do arquivo
                    tbMIXInicio.Text = posição.ToString();
                    tamanho = 1;        //Lê apenas um byte
                    tbMIXBytes.Text = tamanho.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro ao tentar acessar o arquivo");
            }
        }

        private void bMIXProx_Click(object sender, EventArgs e)
        {
            int posição = 0;
            posição = int.Parse(tbMIXInicio.Text) + int.Parse(tbMIXBytes.Text);   //Soma a posição atual a quantidade de bytes a serm lidos 
            tbMIXInicio.Text = posição.ToString();     //Atualiza a o TexbBox com a nova posição de início
            bMIXDados.PerformClick();                      //Dispara o método de leitora de dados
        }
        #endregion

        #region Arquivo BMP (manipulação)
        private void bBMPLer_Click(object sender, EventArgs e)
        {
            int tamanho = 0;
            int posição = 0;

            try
            {
                tamanho = int.Parse(tbBMPBytes.Text);
                posição = int.Parse(tbBMPInicio.Text);
                StringBuilder sb = new StringBuilder(tamanho);

                //Instancimaneto do classe ClassTXT
                ClassBMP bmp = new ClassBMP(arquivoAberto);
                int l = bmp.leHEXA_sem_formatação(tbBMP, posição, tamanho);   //Lê parte do arquivo em HEXA e retorna quantidade de bytes do arquivo
                tbBMPQTB.Text = l.ToString();
                //Evita erro ao ler o arquivo
                if (posição >= l)
                {
                    posição = l - 1;    //Define como a últim posição do arquivo
                    tbBMPInicio.Text = posição.ToString();
                    tamanho = 1;        //Lê apenas um byte
                    tbBMPBytes.Text = tamanho.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro ao tentar acessar o arquivo");
            }
        }

        private void bBMPProx_Click(object sender, EventArgs e)
        {
            int posição = 0;
            posição = int.Parse(tbBMPInicio.Text) + int.Parse(tbBMPBytes.Text);   //Soma a posição atual a quantidade de bytes a serm lidos 
            tbBMPInicio.Text = posição.ToString();      //Atualiza a o TexbBox com a nova posição de início
            bBMPLer.PerformClick();                     //Dispara o método de leitora de dados
        }

        private void rbNormal_CheckedChanged(object sender, EventArgs e)
        {
            if (rbNormal.Checked == true)
                pbBMP.SizeMode = PictureBoxSizeMode.Normal;
        }

        private void rbEsticar_CheckedChanged(object sender, EventArgs e)
        {
            if (rbEsticar.Checked == true)
                pbBMP.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void rbCentralizar_CheckedChanged(object sender, EventArgs e)
        {
            if (rbCentralizar.Checked == true)
                pbBMP.SizeMode = PictureBoxSizeMode.CenterImage;
        }

        private void rbZoom_CheckedChanged(object sender, EventArgs e)
        {
            if (rbZoom.Checked == true)
                pbBMP.SizeMode = PictureBoxSizeMode.Zoom;
        }
        #endregion

    }
}
